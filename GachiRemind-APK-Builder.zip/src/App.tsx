/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Award,
  Bell,
  BellRing,
  Calendar,
  Camera,
  Check,
  Clock,
  Dumbbell,
  Edit3,
  FolderSearch,
  Mic,
  Music,
  Play,
  Plus,
  RotateCcw,
  Search,
  Settings2,
  Square,
  Trash2,
  Upload,
  UserPlus,
  Users,
  Volume2,
} from 'lucide-react';
import {
  CategoryId,
  CategoryItem,
  CoachId,
  CoachProfile,
  DEFAULT_CATEGORIES,
  DEFAULT_COACHES,
  getCurrentMonthKey,
  getCurrentMonthLabel,
  getInitialReminders,
  getTodayDateStr,
  QUICK_TEMPLATES,
  QuickTemplate,
  RANK_TIERS,
  ReminderItem,
  REPEAT_LABELS,
  SOUND_PADS,
} from './data/gachiData';
import {
  playCoachVoiceover,
  playCustomTrackBlob,
  playGachiSound,
  stopAlarmRinger,
  triggerAndroidVibration,
} from './utils/gachiAudio';
import {
  CustomAudioTrack,
  deleteCustomTrack,
  getAllCustomTracks,
  saveCustomTrack,
  saveMultipleCustomTracks,
} from './utils/customTracksDB';
import { CoachAvatar, GymLockerBanner } from './components/GachiArtwork';
import { PWAInstallBanner, OfflineIndicator } from './components/PWAInstallBanner';
import { AndroidAlarmModal } from './components/AndroidAlarmModal';
import { ReminderFormSheet } from './components/ReminderFormSheet';
import {
  CategoryManagerModal,
  CoachCreatorModal,
} from './components/ManagementModals';

type NavTab = 'schedule' | 'coaches' | 'soundboard' | 'stats';
type StatusFilter = 'all' | 'active' | 'completed';
type StatsPeriod = 'day' | 'week' | 'month';

const STORAGE_KEY_REMINDERS = 'gachiremind_items_v6';
const STORAGE_KEY_BUCKS = 'gachiremind_bucks_v6';
const STORAGE_KEY_MONTH = 'gachiremind_month_key_v6';
const STORAGE_KEY_CATEGORIES = 'gachiremind_categories_v1';
const STORAGE_KEY_ALL_COACHES = 'gachiremind_all_coaches_v2';
const STORAGE_KEY_DEFAULT_SONG = 'gachiremind_default_song_v1';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('schedule');
  const [currentMonthKey, setCurrentMonthKey] = useState<string>(() => getCurrentMonthKey());
  const currentMonthLabel = useMemo(() => getCurrentMonthLabel(), [currentMonthKey]);

  // Dynamic Categories State
  const [categories, setCategories] = useState<CategoryItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CATEGORIES);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Fallback
    }
    return DEFAULT_CATEGORIES;
  });

  // Unified Editable Coaches Map (Default 4 + any custom or customized coaches)
  const [coachesMap, setCoachesMap] = useState<Record<string, CoachProfile>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_ALL_COACHES);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') {
          return { ...DEFAULT_COACHES, ...parsed };
        }
      }
    } catch {
      // Fallback
    }
    return { ...DEFAULT_COACHES };
  });

  const [reminders, setReminders] = useState<ReminderItem[]>(() => {
    try {
      const savedMonth = localStorage.getItem(STORAGE_KEY_MONTH);
      const nowMonth = getCurrentMonthKey();
      const saved = localStorage.getItem(STORAGE_KEY_REMINDERS);
      if (saved) {
        const parsed: ReminderItem[] = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // If a new calendar month started, automatically reset completion progress
          if (savedMonth && savedMonth !== nowMonth) {
            return parsed.map((item) => ({
              ...item,
              completed: false,
              completedAt: undefined,
              completedTimestamp: undefined,
              snoozedCount: 0,
            }));
          }
          return parsed;
        }
      }
    } catch {
      // Fallback
    }
    return getInitialReminders();
  });

  const [totalBucks, setTotalBucks] = useState<number>(() => {
    try {
      const savedMonth = localStorage.getItem(STORAGE_KEY_MONTH);
      const nowMonth = getCurrentMonthKey();
      if (savedMonth && savedMonth !== nowMonth) {
        return 0;
      }
      const saved = localStorage.getItem(STORAGE_KEY_BUCKS);
      if (saved !== null) return Math.max(0, Number(saved) || 0);
    } catch {
      // Fallback
    }
    return 0;
  });

  const [defaultSongId, setDefaultSongId] = useState<string | undefined>(() => {
    try {
      return localStorage.getItem(STORAGE_KEY_DEFAULT_SONG) || undefined;
    } catch {
      return undefined;
    }
  });

  const [customTracks, setCustomTracks] = useState<CustomAudioTrack[]>([]);
  const [playingCustomId, setPlayingCustomId] = useState<string | null>(null);
  const [musicSearchQuery, setMusicSearchQuery] = useState('');
  const [isScanningMusic, setIsScanningMusic] = useState(false);

  const singleFileInputRef = useRef<HTMLInputElement | null>(null);
  const multiMusicScanInputRef = useRef<HTMLInputElement | null>(null);
  const quickCoachPhotoInputRef = useRef<HTMLInputElement | null>(null);
  const quickCoachVoiceInputRef = useRef<HTMLInputElement | null>(null);
  const [targetQuickCoachId, setTargetQuickCoachId] = useState<string | null>(null);

  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all');
  const [categoryFilter, setCategoryFilter] = useState<CategoryId | 'all'>('all');
  const [selectedDateStr, setSelectedDateStr] = useState<string>(getTodayDateStr());
  const [selectedCoachId, setSelectedCoachId] = useState<CoachId>('billy');
  const [statsPeriod, setStatsPeriod] = useState<StatsPeriod>('day');

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [isCoachModalOpen, setIsCoachModalOpen] = useState(false);
  const [editingCoach, setEditingCoach] = useState<CoachProfile | null>(null);
  const [editingReminder, setEditingReminder] = useState<ReminderItem | null>(null);
  const [activeAlarmReminder, setActiveAlarmReminder] = useState<ReminderItem | null>(null);
  const [coachToast, setCoachToast] = useState<{ coachId: CoachId; message: string } | null>(null);
  const [notifPermission, setNotifPermission] = useState<NotificationPermission>(
    typeof Notification !== 'undefined' ? Notification.permission : 'default'
  );

  const triggeredKeysRef = useRef<Set<string>>(new Set());

  // Load saved custom tracks from IndexedDB on mount
  useEffect(() => {
    getAllCustomTracks().then((tracks) => {
      setCustomTracks(tracks);
      if (tracks.length > 0 && !defaultSongId) {
        setDefaultSongId(tracks[0].id);
      }
    });
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_REMINDERS, JSON.stringify(reminders));
    } catch {
      // Ignore
    }
  }, [reminders]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_BUCKS, String(totalBucks));
    } catch {
      // Ignore
    }
  }, [totalBucks]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_MONTH, currentMonthKey);
    } catch {
      // Ignore
    }
  }, [currentMonthKey]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_CATEGORIES, JSON.stringify(categories));
    } catch {
      // Ignore
    }
  }, [categories]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_ALL_COACHES, JSON.stringify(coachesMap));
    } catch {
      // Ignore
    }
  }, [coachesMap]);

  useEffect(() => {
    try {
      if (defaultSongId) {
        localStorage.setItem(STORAGE_KEY_DEFAULT_SONG, defaultSongId);
      } else {
        localStorage.removeItem(STORAGE_KEY_DEFAULT_SONG);
      }
    } catch {
      // Ignore
    }
  }, [defaultSongId]);

  const defaultSongObj = useMemo(
    () => customTracks.find((t) => t.id === defaultSongId) || customTracks[0],
    [customTracks, defaultSongId]
  );

  // Real-time background alarm check & automatic monthly progress reset every 4 seconds
  useEffect(() => {
    const checkAlarms = () => {
      const now = new Date();
      const nowMonth = getCurrentMonthKey();

      // Automatic monthly reset when a new calendar month begins
      if (nowMonth !== currentMonthKey) {
        setCurrentMonthKey(nowMonth);
        setTotalBucks(0);
        setReminders((prev) =>
          prev.map((item) => ({
            ...item,
            completed: false,
            completedAt: undefined,
            completedTimestamp: undefined,
            snoozedCount: 0,
          }))
        );
        return;
      }

      const currentHHMM = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      const todayStr = getTodayDateStr();
      const dayOfWeek = now.getDay();
      const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

      for (const item of reminders) {
        if (item.completed) continue;

        let matchesSchedule = false;
        if (item.repeat === 'daily') {
          matchesSchedule = true;
        } else if (item.repeat === 'weekdays') {
          matchesSchedule = !isWeekend;
        } else if (item.repeat === 'weekends') {
          matchesSchedule = isWeekend;
        } else {
          matchesSchedule = item.dateStr === todayStr;
        }

        if (matchesSchedule && item.time === currentHHMM) {
          const triggerKey = `${item.id}_${todayStr}_${currentHHMM}`;
          if (!triggeredKeysRef.current.has(triggerKey)) {
            triggeredKeysRef.current.add(triggerKey);
            setPlayingCustomId(null);
            setActiveAlarmReminder(item);

            if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
              try {
                const coach = coachesMap[item.coachId] || DEFAULT_COACHES.billy;
                new Notification(`${coach.name}: ${item.title}`, {
                  body: item.note || coach.alarmQuotes[0],
                  icon: '/pwa-192x192.png',
                });
              } catch {
                // Ignore Notification constructor restrictions
              }
            }
            break;
          }
        }
      }
    };

    const interval = window.setInterval(checkAlarms, 4000);
    return () => window.clearInterval(interval);
  }, [reminders, coachesMap]);

  const showCoachMessage = (coachId: CoachId, message: string) => {
    setCoachToast({ coachId, message });
    window.setTimeout(() => {
      setCoachToast((prev) => (prev?.message === message ? null : prev));
    }, 4500);
  };

  // Single file upload
  const handleUploadCustomTrack = async (
    file: File,
    customTitle?: string
  ): Promise<CustomAudioTrack | null> => {
    try {
      const saved = await saveCustomTrack(file, customTitle);
      const updated = await getAllCustomTracks();
      setCustomTracks(updated);
      if (!customTitle) {
        setDefaultSongId(saved.id);
      }
      showCoachMessage(
        'billy',
        `Аудио «${saved.name}» сохранено в библиотеке приложения!`
      );
      return saved;
    } catch {
      showCoachMessage('van', 'Не удалось загрузить аудиофайл. Проверь формат файла.');
      return null;
    }
  };

  // Quick photo upload directly onto a coach card
  const handleQuickCoachPhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !targetQuickCoachId) return;
    const coachId = targetQuickCoachId;
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result;
      if (typeof dataUrl === 'string') {
        setCoachesMap((prev) => {
          const existing = prev[coachId];
          if (!existing) return prev;
          return {
            ...prev,
            [coachId]: {
              ...existing,
              customAvatarDataUrl: dataUrl,
            },
          };
        });
        showCoachMessage(coachId, 'Фотография тренера успешно обновлена!');
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Quick unique voiceover upload directly onto a coach card
  const handleQuickCoachVoiceChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !targetQuickCoachId) return;
    const coachId = targetQuickCoachId;
    const coachName = coachesMap[coachId]?.name || 'Тренер';
    const saved = await handleUploadCustomTrack(
      file,
      `Озвучка (${coachName}): ${file.name.replace(/\.[^/.]+$/, '')}`
    );
    if (saved) {
      setCoachesMap((prev) => {
        const existing = prev[coachId];
        if (!existing) return prev;
        return {
          ...prev,
          [coachId]: {
            ...existing,
            voiceTrackId: saved.id,
            voiceTrackName: saved.name,
          },
        };
      });
      await playCoachVoiceover(saved.id, 1.0);
      showCoachMessage(coachId, `Уникальная озвучка «${saved.name}» привязана к тренеру!`);
    }
    e.target.value = '';
  };

  // Device Music Scanner
  const handleScanDeviceForMusic = async () => {
    setIsScanningMusic(true);
    try {
      const win = window as unknown as {
        showDirectoryPicker?: () => Promise<FileSystemDirectoryHandle>;
      };
      if (typeof win.showDirectoryPicker === 'function') {
        try {
          const dirHandle = await win.showDirectoryPicker();
          const foundFiles: File[] = [];
          const scanDir = async (handle: FileSystemDirectoryHandle, depth = 0) => {
            if (depth > 3) return;
            const entries = (
              handle as unknown as {
                values: () => AsyncIterable<FileSystemHandle>;
              }
            ).values();
            for await (const entry of entries) {
              if (entry.kind === 'file') {
                if (/\.(mp3|wav|ogg|m4a|flac|aac|opus)$/i.test(entry.name)) {
                  const file = await (entry as FileSystemFileHandle).getFile();
                  foundFiles.push(file);
                }
              } else if (entry.kind === 'directory') {
                await scanDir(entry as FileSystemDirectoryHandle, depth + 1);
              }
            }
          };
          await scanDir(dirHandle);
          if (foundFiles.length > 0) {
            const saved = await saveMultipleCustomTracks(foundFiles);
            const updated = await getAllCustomTracks();
            setCustomTracks(updated);
            if (saved[0]) setDefaultSongId(saved[0].id);
            showCoachMessage(
              'billy',
              `Найдено и добавлено песен с устройства: ${saved.length}!`
            );
            setIsScanningMusic(false);
            return;
          }
        } catch {
          // Fallback to multi-file input picker
        }
      }
      multiMusicScanInputRef.current?.click();
    } finally {
      setIsScanningMusic(false);
    }
  };

  const handleMultiMusicFilesSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    setIsScanningMusic(true);
    try {
      const files = Array.from(fileList);
      const saved = await saveMultipleCustomTracks(files);
      const updated = await getAllCustomTracks();
      setCustomTracks(updated);
      if (saved.length > 0) {
        setDefaultSongId(saved[0].id);
        showCoachMessage(
          'billy',
          `Найдено и загружено песен с устройства: ${saved.length} шт.!`
        );
      } else {
        showCoachMessage('van', 'В выбранном списке не найдено аудиофайлов.');
      }
    } finally {
      setIsScanningMusic(false);
      e.target.value = '';
    }
  };

  const handleSetSongForAllAlarms = (track: CustomAudioTrack) => {
    setDefaultSongId(track.id);
    setReminders((prev) =>
      prev.map((r) =>
        r.completed
          ? r
          : {
              ...r,
              customTrackId: track.id,
              customTrackName: track.name,
            }
      )
    );
    showCoachMessage(
      'billy',
      `Песня «${track.name}» поставлена на все активные будильники!`
    );
  };

  const handleDeleteCustomTrack = async (id: string) => {
    await deleteCustomTrack(id);
    if (playingCustomId === id) {
      stopAlarmRinger();
      setPlayingCustomId(null);
    }
    const updated = await getAllCustomTracks();
    setCustomTracks(updated);
    if (defaultSongId === id) {
      setDefaultSongId(updated[0]?.id);
    }
    setReminders((prev) =>
      prev.map((r) =>
        r.customTrackId === id
          ? { ...r, customTrackId: undefined, customTrackName: undefined }
          : r
      )
    );
  };

  const requestAndroidNotifications = async () => {
    if (typeof Notification === 'undefined') return;
    try {
      const result = await Notification.requestPermission();
      setNotifPermission(result);
      if (result === 'granted') {
        playGachiSound('three_hundred_bucks', 0.35);
        showCoachMessage('billy', 'Системные уведомления включены!');
      }
    } catch {
      // Ignore
    }
  };

  // Generate 7-day horizontal date scroller around today
  const weekDays = useMemo(() => {
    const base = new Date();
    const days: { dateStr: string; dayShort: string; dayNum: string; isToday: boolean }[] = [];
    const dayNames = ['ВС', 'ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ'];

    for (let offset = -1; offset <= 5; offset++) {
      const d = new Date(base);
      d.setDate(base.getDate() + offset);
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, '0');
      const day = String(d.getDate()).padStart(2, '0');
      const dStr = `${y}-${m}-${day}`;
      days.push({
        dateStr: dStr,
        dayShort: dayNames[d.getDay()],
        dayNum: String(d.getDate()),
        isToday: offset === 0,
      });
    }
    return days;
  }, []);

  const counts = useMemo(() => {
    const active = reminders.filter((r) => !r.completed).length;
    const completed = reminders.filter((r) => r.completed).length;
    return { active, completed, total: reminders.length };
  }, [reminders]);

  // Compute Efficiency Coefficient (КЭ) based on monthly progress (0% - 100%, or 0.00 - 1.00)
  const efficiencyInfo = useMemo(() => {
    if (counts.total === 0) {
      return {
        pct: 0,
        coeffStr: '0.00',
      };
    }
    const rawPct = Math.round((counts.completed / counts.total) * 100);
    const clampedPct = Math.max(0, Math.min(100, rawPct));
    return {
      pct: clampedPct,
      coeffStr: (clampedPct / 100).toFixed(2),
    };
  }, [counts]);

  // Compute current monthly rank and next rank threshold across all 15 ranks
  // Highest rank (Rank 15) requires efficiencyPct >= 95%
  const rankInfo = useMemo(() => {
    let current = RANK_TIERS[0];
    let next = RANK_TIERS[1] || RANK_TIERS[0];
    for (let i = 0; i < RANK_TIERS.length; i++) {
      if (efficiencyInfo.pct >= RANK_TIERS[i].minEfficiencyPct) {
        current = RANK_TIERS[i];
        next = RANK_TIERS[i + 1] || RANK_TIERS[i];
      }
    }
    return {
      current,
      next,
      nextEfficiencyPct:
        next.minEfficiencyPct > current.minEfficiencyPct ? next.minEfficiencyPct : 95,
    };
  }, [efficiencyInfo.pct]);

  const handleResetMonthlyProgress = () => {
    stopAlarmRinger();
    setActiveAlarmReminder(null);
    setTotalBucks(0);
    setCurrentMonthKey(getCurrentMonthKey());
    setReminders((prev) =>
      prev.map((item) => ({
        ...item,
        completed: false,
        completedAt: undefined,
        completedTimestamp: undefined,
        snoozedCount: 0,
      }))
    );
    showCoachMessage(
      'billy',
      `Весь прогресс за ${currentMonthLabel} сброшен до 0%! Начинаем заезд с чистого листа!`
    );
  };

  // Filtered & sorted reminders
  const filteredReminders = useMemo(() => {
    return reminders
      .filter((item) => {
        if (statusFilter === 'active' && item.completed) return false;
        if (statusFilter === 'completed' && !item.completed) return false;
        if (categoryFilter !== 'all' && item.category !== categoryFilter) return false;
        if (item.dateStr !== selectedDateStr && item.repeat === 'once') return false;
        return true;
      })
      .sort((a, b) => {
        if (a.completed !== b.completed) return a.completed ? 1 : -1;
        return a.time.localeCompare(b.time);
      });
  }, [reminders, statusFilter, categoryFilter, selectedDateStr]);

  const filteredCustomTracks = useMemo(() => {
    const q = musicSearchQuery.trim().toLowerCase();
    if (!q) return customTracks;
    return customTracks.filter((t) => t.name.toLowerCase().includes(q));
  }, [customTracks, musicSearchQuery]);

  // Compute Day / Week / Month Statistics honestly from actual progress (0 when reset)
  const periodStats = useMemo(() => {
    const todayStr = getTodayDateStr();
    const nowMs = Date.now();
    const weekAgoMs = nowMs - 7 * 24 * 3600 * 1000;
    const monthPrefix = getCurrentMonthKey();

    if (statsPeriod === 'day') {
      const totalToday = reminders.filter(
        (r) => r.dateStr === todayStr || r.repeat !== 'once'
      );
      const completedToday = totalToday.filter((r) => r.completed);
      const bucksToday = completedToday.reduce((acc, r) => acc + r.rewardBucks, 0);
      const effPct =
        totalToday.length > 0
          ? Math.round((completedToday.length / totalToday.length) * 100)
          : 0;
      return {
        label: 'За сегодня (День)',
        completedCount: completedToday.length,
        totalCount: totalToday.length,
        earnedBucks: bucksToday,
        efficiencyPct: effPct,
        efficiencyCoeff: (effPct / 100).toFixed(2),
      };
    }

    if (statsPeriod === 'week') {
      const completedWeek = reminders.filter(
        (r) =>
          r.completed &&
          (!r.completedTimestamp || r.completedTimestamp >= weekAgoMs)
      );
      const bucksWeek = completedWeek.reduce((acc, r) => acc + r.rewardBucks, 0);
      const effPct =
        reminders.length > 0
          ? Math.round((completedWeek.length / reminders.length) * 100)
          : 0;
      return {
        label: 'За последние 7 дней (Неделя)',
        completedCount: completedWeek.length,
        totalCount: reminders.length,
        earnedBucks: bucksWeek,
        efficiencyPct: effPct,
        efficiencyCoeff: (effPct / 100).toFixed(2),
      };
    }

    const totalMonth = reminders.filter(
      (r) => r.dateStr.startsWith(monthPrefix) || r.repeat !== 'once'
    );
    const completedMonth = totalMonth.filter((r) => r.completed);
    const bucksMonth = completedMonth.reduce((acc, r) => acc + r.rewardBucks, 0);
    const effPct =
      totalMonth.length > 0
        ? Math.round((completedMonth.length / totalMonth.length) * 100)
        : 0;
    return {
      label: `За месяц (${currentMonthLabel})`,
      completedCount: completedMonth.length,
      totalCount: totalMonth.length,
      earnedBucks: bucksMonth,
      efficiencyPct: effPct,
      efficiencyCoeff: (effPct / 100).toFixed(2),
    };
  }, [reminders, statsPeriod, currentMonthLabel]);

  const handleToggleComplete = (id: string) => {
    stopAlarmRinger();
    const target = reminders.find((r) => r.id === id);
    if (!target) return;

    const now = new Date();
    const timeLabel = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    if (!target.completed) {
      playGachiSound('three_hundred_bucks', 0.45);
      triggerAndroidVibration([120, 60, 180]);
      const coach = coachesMap[target.coachId] || DEFAULT_COACHES.billy;
      const praise =
        coach.completionQuotes[Math.floor(Math.random() * coach.completionQuotes.length)];
      showCoachMessage(target.coachId, `${praise} (+$${target.rewardBucks} Bucks)`);
      setTotalBucks((prev) => prev + target.rewardBucks);
    } else {
      setTotalBucks((prev) => Math.max(0, prev - target.rewardBucks));
    }

    setReminders((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              completed: !item.completed,
              completedAt: !item.completed ? timeLabel : undefined,
              completedTimestamp: !item.completed ? Date.now() : undefined,
            }
          : item
      )
    );

    if (activeAlarmReminder?.id === id) {
      setActiveAlarmReminder(null);
    }
  };

  const handleSnoozeReminder = (id: string) => {
    stopAlarmRinger();
    const target = reminders.find((r) => r.id === id);
    if (!target) return;

    const [hh, mm] = target.time.split(':').map(Number);
    const d = new Date();
    d.setHours(hh || 0, (mm || 0) + 10, 0, 0);
    const newTime = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;

    const coach = coachesMap[target.coachId] || DEFAULT_COACHES.billy;
    const snoozeLine =
      coach.snoozeQuotes[Math.floor(Math.random() * coach.snoozeQuotes.length)];
    playGachiSound('gym_whip', 0.4);
    showCoachMessage(target.coachId, `Пит-стоп до ${newTime}: «${snoozeLine}»`);

    setReminders((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              time: newTime,
              snoozedCount: item.snoozedCount + 1,
            }
          : item
      )
    );
    setActiveAlarmReminder(null);
  };

  const handleDeleteReminder = (id: string) => {
    setReminders((prev) => prev.filter((item) => item.id !== id));
  };

  const handleSaveReminder = (
    data: Omit<ReminderItem, 'id' | 'completed' | 'snoozedCount'>
  ) => {
    if (editingReminder) {
      setReminders((prev) =>
        prev.map((item) =>
          item.id === editingReminder.id
            ? {
                ...item,
                ...data,
              }
            : item
        )
      );
      showCoachMessage(data.coachId, `Будильник «${data.title}» обновлён на ${data.time}`);
    } else {
      const newItem: ReminderItem = {
        ...data,
        id: `rem-${Date.now()}`,
        completed: false,
        snoozedCount: 0,
      };
      setReminders((prev) => [newItem, ...prev]);
      playGachiSound(data.soundId, 0.35);
      showCoachMessage(
        data.coachId,
        `Будильник поставлен на ${data.time}: «${data.title}»`
      );
    }
    setEditingReminder(null);
  };

  const handleQuickAddTemplate = (tpl: QuickTemplate) => {
    const target = new Date(Date.now() + tpl.defaultTimeOffsetMin * 60000);
    const tStr = `${String(target.getHours()).padStart(2, '0')}:${String(target.getMinutes()).padStart(2, '0')}`;
    const validCat = categories.some((c) => c.id === tpl.category)
      ? tpl.category
      : categories[0]?.id || 'regime';

    const newItem: ReminderItem = {
      id: `rem-${Date.now()}`,
      title: tpl.title,
      note: tpl.note,
      time: tStr,
      dateStr: selectedDateStr,
      category: validCat,
      coachId: tpl.coachId,
      soundId: tpl.soundId,
      customTrackId: defaultSongObj?.id,
      customTrackName: defaultSongObj?.name,
      repeat: 'daily',
      rewardBucks: tpl.rewardBucks,
      completed: false,
      snoozedCount: 0,
    };
    setReminders((prev) => [newItem, ...prev]);
    playGachiSound(tpl.soundId, 0.35);
    showCoachMessage(tpl.coachId, `Добавлено на ${tStr}: «${tpl.title}»`);
  };

  const handleTriggerDemoAlarm = (item?: ReminderItem) => {
    setPlayingCustomId(null);
    const target =
      item ||
      reminders.find((r) => !r.completed) ||
      reminders[0] || {
        id: 'demo-alarm',
        title: 'Время рабочего подхода и проверки знаний!',
        note: 'Сделай подход в качалке или закрой ДЗ за 300 Bucks',
        time: '18:00',
        dateStr: getTodayDateStr(),
        category: categories[0]?.id || 'regime',
        coachId: 'billy',
        soundId: 'aniki_fanfare',
        customTrackId: defaultSongObj?.id,
        customTrackName: defaultSongObj?.name,
        repeat: 'daily',
        rewardBucks: 300,
        completed: false,
        snoozedCount: 0,
      };
    setActiveAlarmReminder(target);
  };

  return (
    <div className="min-h-screen bg-[#0f1115] text-[#f4f4f6] pb-24 lg:pb-12">
      {/* Hidden File Inputs for Single Upload, Device Music Scanner, Quick Coach Photo & Quick Coach Voiceover */}
      <input
        ref={singleFileInputRef}
        type="file"
        accept="audio/*"
        onChange={async (e) => {
          const file = e.target.files?.[0];
          if (file) {
            await handleUploadCustomTrack(file);
            e.target.value = '';
          }
        }}
        className="hidden"
      />
      <input
        ref={multiMusicScanInputRef}
        type="file"
        accept="audio/*"
        multiple
        onChange={handleMultiMusicFilesSelected}
        className="hidden"
      />
      <input
        ref={quickCoachPhotoInputRef}
        type="file"
        accept="image/*"
        onChange={handleQuickCoachPhotoChange}
        className="hidden"
      />
      <input
        ref={quickCoachVoiceInputRef}
        type="file"
        accept="audio/*"
        onChange={handleQuickCoachVoiceChange}
        className="hidden"
      />

      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 bg-[#0f1115]/90 backdrop-blur-md border-b border-zinc-800/80">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-8 px-4 sm:px-6 h-14">
          {/* Zone 1: Single text element Brand Wordmark */}
          <a
            href="#schedule"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('schedule');
            }}
            className="text-xl font-bold tracking-wider uppercase font-display text-amber-400 whitespace-nowrap shrink-0"
          >
            GachiRemind
          </a>

          {/* Zone 2: 4 concise single-line navigation links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-zinc-300">
            <a
              href="#schedule"
              onClick={(e) => {
                e.preventDefault();
                setActiveTab('schedule');
              }}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
                activeTab === 'schedule'
                  ? 'text-white border-amber-400'
                  : 'border-transparent'
              }`}
            >
              Расписание
            </a>
            <a
              href="#coaches"
              onClick={(e) => {
                e.preventDefault();
                setActiveTab('coaches');
              }}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
                activeTab === 'coaches'
                  ? 'text-white border-amber-400'
                  : 'border-transparent'
              }`}
            >
              Тренеры
            </a>
            <a
              href="#soundboard"
              onClick={(e) => {
                e.preventDefault();
                setActiveTab('soundboard');
              }}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
                activeTab === 'soundboard'
                  ? 'text-white border-amber-400'
                  : 'border-transparent'
              }`}
            >
              Дека звуков
            </a>
            <a
              href="#stats"
              onClick={(e) => {
                e.preventDefault();
                setActiveTab('stats');
              }}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 py-1 border-b-2 ${
                activeTab === 'stats'
                  ? 'text-white border-amber-400'
                  : 'border-transparent'
              }`}
            >
              Статистика
            </a>
          </nav>

          {/* Zone 3: 1 Primary Action Button */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => {
                setEditingReminder(null);
                setIsFormOpen(true);
              }}
              className="min-h-[40px] px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs sm:text-sm font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>Создать будильник</span>
            </button>
          </div>
        </div>
      </header>

      {/* Coach Motivational Toast Notification */}
      {coachToast && (
        <div className="fixed top-16 right-4 left-4 sm:left-auto sm:max-w-md z-40 rounded-2xl bg-zinc-900/95 backdrop-blur-md border border-amber-500/40 p-3.5 shadow-2xl flex items-center gap-3">
          <CoachAvatar coach={coachesMap[coachToast.coachId]} size="sm" />
          <div className="min-w-0 flex-1">
            <div className="text-xs font-semibold text-amber-400">
              {(coachesMap[coachToast.coachId] || DEFAULT_COACHES.billy).name}
            </div>
            <div className="text-xs text-zinc-200 mt-0.5 leading-snug">
              {coachToast.message}
            </div>
          </div>
        </div>
      )}

      {/* Main Content Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 pt-5 space-y-6">
        {/* Hero Gym Locker Banner */}
        <GymLockerBanner
          totalBucks={totalBucks}
          rankTitle={rankInfo.current.title}
          rankBadge={rankInfo.current.badgeLabel}
          nextRankTitle={rankInfo.next.title}
          nextRankEfficiencyPct={rankInfo.nextEfficiencyPct}
          efficiencyPct={efficiencyInfo.pct}
          monthLabel={currentMonthLabel}
          completedCount={counts.completed}
          activeCount={counts.active}
          isAlarmPlaying={activeAlarmReminder !== null}
          onResetMonthlyProgress={handleResetMonthlyProgress}
        />

        {/* Android PWA Installation Banner */}
        <PWAInstallBanner />

        {/* TAB 1: SCHEDULE & REMINDERS */}
        {activeTab === 'schedule' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left 8 Columns */}
            <div className="lg:col-span-8 space-y-5">
              <div className="rounded-2xl bg-zinc-900 border border-zinc-800 p-4 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-2 text-xs text-zinc-400">
                    <Calendar className="w-4 h-4 text-amber-400" />
                    <span>Расписание заездов и задач</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono-tabular text-zinc-200">{selectedDateStr}</span>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setIsCategoryModalOpen(true)}
                      className="min-h-[40px] px-3 py-1.5 rounded-xl bg-zinc-950 hover:bg-zinc-800 text-zinc-200 border border-zinc-800 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
                    >
                      <Settings2 className="w-3.5 h-3.5 text-amber-400" />
                      <span>Редактировать рубрики</span>
                    </button>

                    {typeof Notification !== 'undefined' && notifPermission !== 'granted' && (
                      <button
                        type="button"
                        onClick={requestAndroidNotifications}
                        className="min-h-[40px] px-3 py-1.5 rounded-xl bg-zinc-950 hover:bg-zinc-800 text-zinc-300 border border-zinc-800 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
                      >
                        <Bell className="w-3.5 h-3.5 text-amber-400" />
                        <span>Разрешить Push</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* 7-Day Android Date Scroller */}
                <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
                  {weekDays.map((d) => {
                    const isSelected = selectedDateStr === d.dateStr;
                    return (
                      <button
                        key={d.dateStr}
                        type="button"
                        onClick={() => setSelectedDateStr(d.dateStr)}
                        className={`min-h-[54px] rounded-xl flex flex-col items-center justify-center transition-colors border cursor-pointer ${
                          isSelected
                            ? 'bg-amber-500 text-zinc-950 border-amber-500 font-bold'
                            : 'bg-zinc-950 text-zinc-300 border-zinc-800/90 hover:bg-zinc-800'
                        }`}
                      >
                        <span className="text-[10px] uppercase tracking-wider opacity-80">
                          {d.isToday ? 'СЕГ' : d.dayShort}
                        </span>
                        <span className="text-sm sm:text-base font-mono-tabular mt-0.5">
                          {d.dayNum}
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Interactive Segmented Filters */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-zinc-800/80">
                  <div className="flex items-center gap-1 p-1 bg-zinc-950 rounded-xl border border-zinc-800/80 shrink-0">
                    {(
                      [
                        { id: 'all', label: `Все (${counts.total})` },
                        { id: 'active', label: `В плане (${counts.active})` },
                        { id: 'completed', label: `Готово (${counts.completed})` },
                      ] as const
                    ).map((st) => (
                      <button
                        key={st.id}
                        type="button"
                        onClick={() => setStatusFilter(st.id)}
                        className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                          statusFilter === st.id
                            ? 'bg-zinc-800 text-white shadow-sm'
                            : 'text-zinc-400 hover:text-zinc-200'
                        }`}
                      >
                        {st.label}
                      </button>
                    ))}
                  </div>

                  {/* Dynamic Category Filter */}
                  <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
                    <button
                      type="button"
                      onClick={() => setCategoryFilter('all')}
                      className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                        categoryFilter === 'all'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          : 'text-zinc-400 hover:text-zinc-200'
                      }`}
                    >
                      Все рубрики
                    </button>
                    {categories.map((cat) => (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => setCategoryFilter(cat.id)}
                        className={`min-h-[36px] px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                          categoryFilter === cat.id
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                            : 'text-zinc-400 hover:text-zinc-200'
                        }`}
                      >
                        {cat.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Reminder List */}
              {filteredReminders.length === 0 ? (
                <div className="rounded-3xl bg-zinc-900 border border-zinc-800 p-10 text-center">
                  <div className="w-14 h-14 rounded-2xl bg-zinc-800 text-amber-400 flex items-center justify-center mx-auto mb-4">
                    <Dumbbell className="w-7 h-7" />
                  </div>
                  <h3 className="text-lg font-bold text-white font-display uppercase tracking-wide">
                    В этой рубрике пока нет будильников
                  </h3>
                  <p className="text-sm text-zinc-400 max-w-md mx-auto mt-1">
                    Добавь новый будильник со своей песней или выбери готовый шаблон по рубрикам.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setEditingReminder(null);
                      setIsFormOpen(true);
                    }}
                    className="mt-5 min-h-[44px] px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-sm font-bold transition-colors inline-flex items-center gap-2 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Создать будильник</span>
                  </button>
                </div>
              ) : (
                <div className="rounded-3xl bg-zinc-900 border border-zinc-800 divide-y divide-zinc-800/80 overflow-hidden">
                  {filteredReminders.map((item) => {
                    const coach = coachesMap[item.coachId] || DEFAULT_COACHES.billy;
                    const categoryObj = categories.find((c) => c.id === item.category);
                    const soundObj = SOUND_PADS.find((s) => s.id === item.soundId);
                    const effectiveSongName =
                      item.customTrackName ||
                      (defaultSongObj ? defaultSongObj.name : undefined);
                    const soundLabel = effectiveSongName
                      ? `Песня: ${effectiveSongName}`
                      : soundObj?.title || 'Сигнал';

                    return (
                      <div
                        key={item.id}
                        className={`p-4 sm:p-5 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                          item.completed ? 'bg-zinc-950/50 opacity-75' : 'hover:bg-zinc-800/40'
                        }`}
                      >
                        <div className="flex items-start gap-3.5 min-w-0 flex-1">
                          <button
                            type="button"
                            onClick={() => handleToggleComplete(item.id)}
                            aria-label={
                              item.completed
                                ? `Вернуть в план: ${item.title}`
                                : `Отметить выполненным: ${item.title}`
                            }
                            className={`min-h-[44px] min-w-[44px] rounded-2xl border flex items-center justify-center shrink-0 transition-colors cursor-pointer ${
                              item.completed
                                ? 'bg-amber-500 border-amber-500 text-zinc-950'
                                : 'bg-zinc-950 border-zinc-700 hover:border-amber-400 text-transparent'
                            }`}
                          >
                            <Check className="w-5 h-5 stroke-[2.5]" />
                          </button>

                          <div className="min-w-0 flex-1">
                            {/* Clean unboxed Zero-Pill metadata with middot separators */}
                            <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-zinc-400">
                              <span className="font-mono-tabular font-bold text-amber-400 text-sm">
                                {item.time}
                              </span>
                              <span aria-hidden="true">·</span>
                              <span className="text-zinc-200 font-medium">
                                {categoryObj?.label || 'Рубрика'}
                              </span>
                              <span aria-hidden="true">·</span>
                              <span>{coach.name}</span>
                              <span aria-hidden="true">·</span>
                              <span className="text-amber-300/90">{soundLabel}</span>
                              <span aria-hidden="true">·</span>
                              <span className="font-mono-tabular text-zinc-300">
                                +${item.rewardBucks} Bucks
                              </span>
                              <span aria-hidden="true">·</span>
                              <span>{REPEAT_LABELS[item.repeat]}</span>
                            </div>

                            <h3
                              className={`mt-1 text-base sm:text-lg font-semibold leading-snug ${
                                item.completed
                                  ? 'line-through text-zinc-500'
                                  : 'text-white'
                              }`}
                            >
                              {item.title}
                            </h3>

                            {item.note && (
                              <p className="mt-1 text-xs sm:text-sm text-zinc-400 leading-relaxed">
                                {item.note}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Right Action Hitboxes */}
                        <div className="flex items-center justify-end gap-1.5 shrink-0 pl-12 sm:pl-0">
                          <CoachAvatar coach={coach} size="sm" className="mr-1" />

                          <button
                            type="button"
                            onClick={() => handleTriggerDemoAlarm(item)}
                            className="min-h-[44px] px-3 rounded-xl bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-xs font-medium text-amber-400 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
                            title="Запустить будильник сейчас"
                          >
                            <BellRing className="w-4 h-4" />
                            <span>Будильник</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setEditingReminder(item);
                              setIsFormOpen(true);
                            }}
                            className="min-h-[44px] min-w-[44px] rounded-xl bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 flex items-center justify-center transition-colors cursor-pointer"
                            aria-label="Редактировать будильник"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>

                          <button
                            type="button"
                            onClick={() => handleDeleteReminder(item.id)}
                            className="min-h-[44px] min-w-[44px] rounded-xl bg-zinc-950 hover:bg-rose-950/60 border border-zinc-800 hover:border-rose-800 text-zinc-400 hover:text-rose-400 flex items-center justify-center transition-colors cursor-pointer"
                            aria-label="Удалить будильник"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Right 4 Columns: Device Music Scanner + Quick Templates */}
            <aside className="lg:col-span-4 space-y-5">
              {/* Custom Device Music Card */}
              <div className="rounded-3xl bg-zinc-900 border border-zinc-800 p-5 space-y-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h2 className="text-lg font-bold text-white font-display uppercase tracking-wide">
                      Песня пользователя на будильник
                    </h2>
                    <p className="text-xs text-zinc-400 mt-0.5">
                      Найди все песни на устройстве или загрузи трек, чтобы будильник играл твою музыку
                    </p>
                  </div>
                  <Music className="w-5 h-5 text-amber-400 shrink-0 mt-1" />
                </div>

                <div className="grid grid-cols-1 gap-2">
                  <button
                    type="button"
                    onClick={handleScanDeviceForMusic}
                    disabled={isScanningMusic}
                    className="w-full min-h-[44px] px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <FolderSearch className="w-4 h-4" />
                    <span>
                      {isScanningMusic
                        ? 'Поиск аудиофайлов...'
                        : 'Найти музыку на устройстве'}
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => singleFileInputRef.current?.click()}
                    className="w-full min-h-[42px] px-4 py-2 rounded-xl bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-zinc-200 text-xs font-medium flex items-center justify-center gap-2 transition-colors cursor-pointer whitespace-nowrap"
                  >
                    <Upload className="w-4 h-4 text-amber-400" />
                    <span>Добавить одну песню</span>
                  </button>
                </div>

                {customTracks.length === 0 ? (
                  <p className="text-xs text-zinc-500 text-center py-2">
                    Нажми «Найти музыку на устройстве», чтобы выбрать папку или файлы MP3/WAV/M4A.
                  </p>
                ) : (
                  <div className="divide-y divide-zinc-800/80 max-h-60 overflow-y-auto pr-1">
                    {customTracks.map((track) => {
                      const isPlaying = playingCustomId === track.id;
                      const isDefault = defaultSongObj?.id === track.id;
                      return (
                        <div
                          key={track.id}
                          className="py-2.5 first:pt-0 last:pb-0 flex items-center justify-between gap-2"
                        >
                          <button
                            type="button"
                            onClick={() => handleSetSongForAllAlarms(track)}
                            className="min-w-0 flex-1 text-left cursor-pointer"
                          >
                            <div className="text-xs font-semibold text-white truncate">
                              {track.name}
                            </div>
                            <div className="text-[11px] text-zinc-400">
                              {isDefault ? (
                                <span className="text-amber-400 font-medium">
                                  Активная песня будильника
                                </span>
                              ) : (
                                <span>Нажми, чтобы поставить на будильник</span>
                              )}
                            </div>
                          </button>

                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              type="button"
                              onClick={async () => {
                                if (isPlaying) {
                                  stopAlarmRinger();
                                  setPlayingCustomId(null);
                                } else {
                                  setPlayingCustomId(track.id);
                                  await playCustomTrackBlob(track.blob, false, 0.85);
                                }
                              }}
                              className="min-h-[38px] min-w-[38px] rounded-xl bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-amber-400 flex items-center justify-center cursor-pointer"
                              aria-label={isPlaying ? 'Остановить' : 'Воспроизвести'}
                            >
                              {isPlaying ? (
                                <Square className="w-3.5 h-3.5 fill-current" />
                              ) : (
                                <Play className="w-3.5 h-3.5 fill-current" />
                              )}
                            </button>

                            <button
                              type="button"
                              onClick={() => handleDeleteCustomTrack(track.id)}
                              className="min-h-[38px] min-w-[38px] rounded-xl bg-zinc-950 hover:bg-rose-950/60 border border-zinc-800 text-zinc-400 hover:text-rose-400 flex items-center justify-center cursor-pointer"
                              aria-label="Удалить трек"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Quick Templates by Category */}
              <div className="rounded-3xl bg-zinc-900 border border-zinc-800 p-5">
                <h2 className="text-lg font-bold text-white font-display uppercase tracking-wide">
                  Быстрые шаблоны по рубрикам
                </h2>
                <p className="text-xs text-zinc-400 mt-1">
                  Добавь будильник в одно касание
                </p>

                <div className="mt-4 divide-y divide-zinc-800/80">
                  {QUICK_TEMPLATES.map((tpl) => {
                    const coach = coachesMap[tpl.coachId] || DEFAULT_COACHES.billy;
                    const cat = categories.find((c) => c.id === tpl.category);
                    return (
                      <div
                        key={tpl.title}
                        className="py-3 first:pt-0 last:pb-0 flex items-center justify-between gap-3"
                      >
                        <div className="min-w-0">
                          <div className="text-xs text-zinc-400">
                            {cat?.label || 'Рубрика'} · {coach.name} · +${tpl.rewardBucks}
                          </div>
                          <div className="text-sm font-medium text-zinc-100 truncate mt-0.5">
                            {tpl.title}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleQuickAddTemplate(tpl)}
                          className="min-h-[44px] min-w-[44px] rounded-xl bg-zinc-800 hover:bg-amber-500 hover:text-zinc-950 text-amber-400 flex items-center justify-center shrink-0 transition-colors cursor-pointer"
                          aria-label={`Добавить шаблон ${tpl.title}`}
                        >
                          <Plus className="w-4 h-4 stroke-[2.5]" />
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            </aside>
          </div>
        )}

        {/* TAB 2: COACHES (With Custom Photo & Unique Voiceover per Coach!) */}
        {activeTab === 'coaches' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
              <div>
                <h2 className="text-2xl sm:text-3xl font-bold text-white font-display uppercase tracking-wide">
                  Тренеры раздевалки и пилоты Гран-при
                </h2>
                <p className="text-sm text-zinc-400 mt-1">
                  Каждому тренеру можно поставить своё фото с устройства и записать или загрузить уникальную озвучку для будильника.
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  setEditingCoach(null);
                  setIsCoachModalOpen(true);
                }}
                className="min-h-[44px] px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs sm:text-sm font-bold flex items-center gap-2 self-start cursor-pointer whitespace-nowrap"
              >
                <UserPlus className="w-4 h-4" />
                <span>Добавить нового тренера</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              {Object.values(coachesMap).map((coach) => {
                const isSelected = selectedCoachId === coach.id;
                const assignedCount = reminders.filter((r) => r.coachId === coach.id).length;

                return (
                  <div
                    key={coach.id}
                    className={`rounded-3xl bg-zinc-900 border p-6 flex flex-col justify-between gap-5 transition-colors ${
                      isSelected ? 'border-amber-500' : 'border-zinc-800'
                    }`}
                  >
                    <div className="space-y-4">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-4 min-w-0">
                          <CoachAvatar coach={coach} size="xl" />
                          <div className="min-w-0 flex-1">
                            <div className="text-xs text-amber-400 font-medium">
                              {coach.title} · Будильников: {assignedCount}
                            </div>
                            <h3 className="text-2xl font-bold text-white font-display uppercase tracking-wide mt-0.5 truncate">
                              {coach.name}
                            </h3>
                            <p className="text-xs text-zinc-400 mt-1">
                              Специализация: {coach.specialty}
                            </p>
                            <div className="mt-1.5 text-xs text-zinc-300">
                              Озвучка:{' '}
                              <span className="text-amber-400 font-medium">
                                {coach.voiceTrackName ||
                                  SOUND_PADS.find((s) => s.id === coach.defaultSound)?.title ||
                                  'Стандартный сигнал'}
                              </span>
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingCoach(coach);
                              setIsCoachModalOpen(true);
                            }}
                            className="min-h-[40px] px-3 rounded-xl bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-zinc-200 text-xs font-medium flex items-center gap-1.5 cursor-pointer"
                            title="Настроить фото и уникальную озвучку"
                          >
                            <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                            <span>Настроить</span>
                          </button>

                          {coach.isCustom && (
                            <button
                              type="button"
                              onClick={() => {
                                setCoachesMap((prev) => {
                                  const next = { ...prev };
                                  delete next[coach.id];
                                  return next;
                                });
                              }}
                              className="min-h-[40px] min-w-[40px] rounded-xl bg-zinc-950 hover:bg-rose-950/60 border border-zinc-800 text-zinc-400 hover:text-rose-400 flex items-center justify-center shrink-0 cursor-pointer"
                              aria-label={`Удалить тренера ${coach.name}`}
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      </div>

                      <p className="text-sm text-zinc-300 leading-relaxed">
                        {coach.bio}
                      </p>

                      {/* Direct Quick Buttons for Photo & Unique Voiceover */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => {
                            setTargetQuickCoachId(coach.id);
                            quickCoachPhotoInputRef.current?.click();
                          }}
                          className="min-h-[42px] px-3 py-2 rounded-xl bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-xs font-medium text-zinc-200 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                        >
                          <Camera className="w-4 h-4 text-amber-400" />
                          <span>Поставить фото тренера</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setTargetQuickCoachId(coach.id);
                            quickCoachVoiceInputRef.current?.click();
                          }}
                          className="min-h-[42px] px-3 py-2 rounded-xl bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-xs font-medium text-zinc-200 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                        >
                          <Mic className="w-4 h-4 text-amber-400" />
                          <span>Загрузить озвучку тренера</span>
                        </button>
                      </div>

                      <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800/80 space-y-1.5">
                        <div className="text-xs font-medium text-zinc-400">
                          Девиз на экране будильника:
                        </div>
                        <p className="text-sm text-zinc-100 italic">
                          «{coach.alarmQuotes[0]}»
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-3 pt-2">
                      <button
                        type="button"
                        onClick={async () => {
                          setSelectedCoachId(coach.id);
                          if (coach.voiceTrackId) {
                            const played = await playCoachVoiceover(coach.voiceTrackId, 1.0);
                            if (played) {
                              showCoachMessage(
                                coach.id,
                                `Звучит уникальная озвучка: ${coach.voiceTrackName || coach.name}`
                              );
                              return;
                            }
                          }
                          if (coach.defaultCustomTrackId) {
                            const found = customTracks.find(
                              (t) => t.id === coach.defaultCustomTrackId
                            );
                            if (found) {
                              await playCustomTrackBlob(found.blob, false, 0.85);
                              showCoachMessage(coach.id, `Играет песня тренера: ${found.name}`);
                              return;
                            }
                          }
                          playGachiSound(coach.defaultSound, 0.5);
                          showCoachMessage(coach.id, `«${coach.alarmQuotes[0]}»`);
                        }}
                        className="min-h-[44px] px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white text-xs font-semibold flex items-center gap-2 transition-colors cursor-pointer"
                      >
                        <Volume2 className="w-4 h-4 text-amber-400" />
                        <span>Прослушать озвучку</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setEditingReminder(null);
                          setIsFormOpen(true);
                        }}
                        className="min-h-[44px] px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Поставить будильник</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 3: SOUNDBOARD & DEVICE MUSIC SCANNER */}
        {activeTab === 'soundboard' && (
          <div className="space-y-6">
            <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
              <div>
                <h2 className="text-2xl sm:text-3xl font-bold text-white font-display uppercase tracking-wide">
                  Дека звуков и поиск музыки на устройстве
                </h2>
                <p className="text-sm text-zinc-400 mt-1">
                  Сканируй папку с музыкой на своём телефоне или ПК, добавляй свои звуки и ставь любимые песни на будильник.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <button
                  type="button"
                  onClick={handleScanDeviceForMusic}
                  disabled={isScanningMusic}
                  className="min-h-[44px] px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs sm:text-sm font-bold flex items-center gap-2 cursor-pointer whitespace-nowrap"
                >
                  <FolderSearch className="w-4 h-4" />
                  <span>
                    {isScanningMusic
                      ? 'Сканирование устройства...'
                      : 'Найти музыку на устройстве'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => singleFileInputRef.current?.click()}
                  className="min-h-[44px] px-4 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs sm:text-sm font-semibold text-zinc-100 flex items-center gap-2 cursor-pointer whitespace-nowrap"
                >
                  <Upload className="w-4 h-4 text-amber-400" />
                  <span>Добавить свой звук / песню</span>
                </button>
              </div>
            </div>

            {/* Device Music Finder List */}
            <div className="rounded-3xl bg-zinc-900 border border-zinc-800 p-5 sm:p-6 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-lg font-bold text-white font-display uppercase tracking-wide">
                    Список музыки и озвучек с твоего устройства ({customTracks.length})
                  </h3>
                  <p className="text-xs text-zinc-400">
                    Все найденные и добавленные треки сохраняются локально и работают на будильнике офлайн
                  </p>
                </div>

                {customTracks.length > 0 && (
                  <div className="relative w-full sm:w-64">
                    <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={musicSearchQuery}
                      onChange={(e) => setMusicSearchQuery(e.target.value)}
                      placeholder="Поиск песни в списке..."
                      className="w-full min-h-[40px] pl-9 pr-3 py-1.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
                    />
                  </div>
                )}
              </div>

              {customTracks.length === 0 ? (
                <div className="rounded-2xl bg-zinc-950 border border-zinc-800/80 p-8 text-center space-y-3">
                  <Music className="w-8 h-8 text-amber-400 mx-auto" />
                  <div className="text-sm font-semibold text-white">
                    Музыка с устройства ещё не просканирована
                  </div>
                  <p className="text-xs text-zinc-400 max-w-md mx-auto">
                    Нажми кнопку «Найти музыку на устройстве», выбери папку с песнями или отметь сразу несколько треков — они появятся в этом списке.
                  </p>
                  <button
                    type="button"
                    onClick={handleScanDeviceForMusic}
                    className="min-h-[42px] px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold inline-flex items-center gap-2 cursor-pointer"
                  >
                    <FolderSearch className="w-4 h-4" />
                    <span>Запустить поиск музыки</span>
                  </button>
                </div>
              ) : (
                <div className="divide-y divide-zinc-800/80 max-h-96 overflow-y-auto">
                  {filteredCustomTracks.map((track) => {
                    const isPlaying = playingCustomId === track.id;
                    const isDefault = defaultSongObj?.id === track.id;
                    return (
                      <div
                        key={track.id}
                        className="py-3 first:pt-0 last:pb-0 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 text-xs text-zinc-400">
                            <span>{(track.sizeBytes / (1024 * 1024)).toFixed(1)} МБ</span>
                            <span aria-hidden="true">·</span>
                            <span>{track.subtitle || 'Музыка с устройства'}</span>
                            {isDefault && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span className="text-amber-400 font-semibold">
                                  Основная песня будильника
                                </span>
                              </>
                            )}
                          </div>
                          <div className="text-sm sm:text-base font-bold text-white truncate mt-0.5">
                            {track.name}
                          </div>
                        </div>

                        <div className="flex flex-wrap items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={async () => {
                              if (isPlaying) {
                                stopAlarmRinger();
                                setPlayingCustomId(null);
                              } else {
                                setPlayingCustomId(track.id);
                                await playCustomTrackBlob(track.blob, false, 0.9);
                              }
                            }}
                            className="min-h-[40px] px-3.5 py-1.5 rounded-xl bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-xs font-semibold text-white flex items-center gap-1.5 cursor-pointer"
                          >
                            {isPlaying ? (
                              <>
                                <Square className="w-3.5 h-3.5 text-amber-400 fill-current" />
                                <span>Стоп</span>
                              </>
                            ) : (
                              <>
                                <Play className="w-3.5 h-3.5 text-amber-400 fill-current" />
                                <span>Слушать</span>
                              </>
                            )}
                          </button>

                          <button
                            type="button"
                            onClick={() => handleSetSongForAllAlarms(track)}
                            className={`min-h-[40px] px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer ${
                              isDefault
                                ? 'bg-amber-500 text-zinc-950'
                                : 'bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/40'
                            }`}
                          >
                            <BellRing className="w-3.5 h-3.5" />
                            <span>
                              {isDefault ? 'Стоит на будильнике' : 'Поставить на будильник'}
                            </span>
                          </button>

                          <button
                            type="button"
                            onClick={() => handleDeleteCustomTrack(track.id)}
                            className="min-h-[40px] min-w-[40px] rounded-xl bg-zinc-950 hover:bg-rose-950/60 border border-zinc-800 text-zinc-400 hover:text-rose-400 flex items-center justify-center cursor-pointer"
                            aria-label="Удалить песню"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Built-in Gachi & F1 Sound Pads */}
            <div>
              <h3 className="text-lg font-bold text-white font-display uppercase tracking-wide mb-3">
                Встроенные сигналы Качалки и Формулы-1
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {SOUND_PADS.map((pad) => {
                  const coach = coachesMap[pad.coachId] || DEFAULT_COACHES.billy;
                  return (
                    <div
                      key={pad.id}
                      className="rounded-3xl bg-zinc-900 border border-zinc-800 p-5 flex flex-col justify-between gap-4"
                    >
                      <div>
                        <div className="flex items-center justify-between gap-3 mb-3">
                          <div className="text-xs text-zinc-400">
                            {coach.name} · {pad.bpmLabel}
                          </div>
                          <CoachAvatar coach={coach} size="sm" />
                        </div>

                        <h3 className="text-xl font-bold text-white font-display uppercase tracking-wide">
                          {pad.title}
                        </h3>
                        <p className="text-xs text-zinc-400 mt-1">{pad.subtitle}</p>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          stopAlarmRinger();
                          setPlayingCustomId(null);
                          playGachiSound(pad.id, 0.55);
                          triggerAndroidVibration([100, 50, 150]);
                          showCoachMessage(pad.coachId, `${pad.title}: ${pad.phrase}`);
                        }}
                        className="w-full min-h-[48px] rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-[0.98] text-zinc-950 font-bold text-sm flex items-center justify-center gap-2 transition-transform cursor-pointer"
                      >
                        <Volume2 className="w-4 h-4" />
                        <span>Врубить сигнал</span>
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: STATS & 15 RANKS */}
        {activeTab === 'stats' && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div>
                <h2 className="text-2xl sm:text-3xl font-bold text-white font-display uppercase tracking-wide">
                  Статистика телеметрии и 15 рангов раздевалки
                </h2>
                <p className="text-sm text-zinc-400 mt-1">
                  Анализ выполненных задач, ДЗ и тренировок за день, за неделю и за месяц.
                </p>
              </div>

              {/* 3-Period Segmented Selector: За день / За неделю / За месяц */}
              <div className="flex items-center gap-1 p-1 bg-zinc-900 rounded-2xl border border-zinc-800 self-start">
                {(
                  [
                    { id: 'day', label: 'За день' },
                    { id: 'week', label: 'За неделю' },
                    { id: 'month', label: 'За месяц' },
                  ] as const
                ).map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setStatsPeriod(p.id)}
                    className={`min-h-[40px] px-4 py-1.5 rounded-xl text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
                      statsPeriod === p.id
                        ? 'bg-amber-500 text-zinc-950'
                        : 'text-zinc-300 hover:text-white'
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Period Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="rounded-3xl bg-zinc-900 border border-zinc-800 p-5">
                <div className="text-xs text-zinc-400">
                  Коэффициент эффективности ({periodStats.label})
                </div>
                <div className="text-3xl font-bold text-amber-400 font-mono-tabular mt-1">
                  КЭ {periodStats.efficiencyCoeff} ({periodStats.efficiencyPct}%)
                </div>
                <div className="text-xs text-zinc-400 mt-2">
                  Высший ранг месяца: требуется <span className="font-mono-tabular text-white font-semibold">95% (КЭ 0.95)</span>
                </div>
              </div>

              <div className="rounded-3xl bg-zinc-900 border border-zinc-800 p-5">
                <div className="text-xs text-zinc-400">
                  Выполнено задач ({periodStats.label})
                </div>
                <div className="text-3xl font-bold text-white font-mono-tabular mt-1">
                  {periodStats.completedCount} из {periodStats.totalCount}
                </div>
                <div className="text-xs text-zinc-400 mt-2">
                  Сезон: <span className="text-amber-400 font-semibold">{currentMonthLabel}</span> (автосброс каждый месяц)
                </div>
              </div>

              <div className="rounded-3xl bg-zinc-900 border border-zinc-800 p-5">
                <div className="text-xs text-zinc-400">
                  Заработано за период ({periodStats.label})
                </div>
                <div className="text-3xl font-bold text-white font-mono-tabular mt-1">
                  +${periodStats.earnedBucks} Bucks
                </div>
                <div className="text-xs text-amber-400 mt-2">
                  Ранг месяца: {rankInfo.current.title}
                </div>
              </div>
            </div>

            {/* Breakdown by Editable Categories */}
            <div className="rounded-3xl bg-zinc-900 border border-zinc-800 p-6 space-y-4">
              <div className="flex items-center justify-between gap-4">
                <h3 className="text-lg font-bold text-white font-display uppercase tracking-wide">
                  Статистика по рубрикам ({periodStats.label})
                </h3>
                <button
                  type="button"
                  onClick={() => setIsCategoryModalOpen(true)}
                  className="text-xs font-medium text-amber-400 hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <Settings2 className="w-3.5 h-3.5" />
                  <span>Редактировать рубрики</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {categories.map((cat) => {
                  const catTotal = reminders.filter((r) => r.category === cat.id).length;
                  const catDone = reminders.filter(
                    (r) => r.category === cat.id && r.completed
                  ).length;
                  const catEffPct =
                    catTotal > 0 ? Math.round((catDone / catTotal) * 100) : 0;

                  return (
                    <div
                      key={cat.id}
                      className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 flex items-center justify-between gap-3"
                    >
                      <div className="min-w-0">
                        <div className="text-sm font-bold text-white truncate">
                          {cat.label}
                        </div>
                        <div className="text-xs text-zinc-400 truncate mt-0.5">
                          {cat.description}
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="text-base font-bold font-mono-tabular text-amber-400">
                          {catDone}/{catTotal} ({catEffPct}%)
                        </div>
                        <div className="text-[11px] text-zinc-500">
                          КЭ {(catEffPct / 100).toFixed(2)}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Full Ladder of 15 Monthly Ranks (Highest Rank requires 95% Efficiency) */}
            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h3 className="text-lg font-bold text-white font-display uppercase tracking-wide">
                    Лестница из 15 рангов месяца (Высший ранг — при 95% эффективности)
                  </h3>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    Прогресс и ранги автоматически сбрасываются 1-го числа каждого месяца. Текущий КЭ: {efficiencyInfo.coeffStr} ({efficiencyInfo.pct}%).
                  </p>
                </div>
                <span className="text-xs text-zinc-400 font-mono-tabular">
                  Открыто: {RANK_TIERS.filter((t) => efficiencyInfo.pct >= t.minEfficiencyPct).length} из {RANK_TIERS.length}
                </span>
              </div>

              <div className="rounded-3xl bg-zinc-900 border border-zinc-800 divide-y divide-zinc-800/80 overflow-hidden">
                {RANK_TIERS.map((tier) => {
                  const unlocked = efficiencyInfo.pct >= tier.minEfficiencyPct;
                  const isCurrent = rankInfo.current.id === tier.id;
                  const tierCoeff = (tier.minEfficiencyPct / 100).toFixed(2);
                  return (
                    <div
                      key={tier.id}
                      className={`p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                        isCurrent ? 'bg-amber-500/10' : ''
                      }`}
                    >
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2 text-xs text-zinc-400">
                          <span className="font-semibold text-zinc-200">{tier.badgeLabel}</span>
                          <span aria-hidden="true">·</span>
                          <span className="font-mono-tabular text-amber-400 font-semibold">
                            Требуется эффективность: {tier.minEfficiencyPct}% (КЭ {tierCoeff})
                          </span>
                          {isCurrent && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="text-white font-semibold">
                                Твой текущий ранг месяца
                              </span>
                            </>
                          )}
                        </div>
                        <h4 className="text-base sm:text-lg font-bold text-white font-display uppercase tracking-wide">
                          {tier.title}
                        </h4>
                        <p className="text-xs text-zinc-400">{tier.subtitle}</p>
                      </div>

                      <div className="text-xs font-mono-tabular font-semibold shrink-0">
                        {unlocked ? (
                          <span className="text-amber-400 flex items-center gap-1.5">
                            <Check className="w-4 h-4" />
                            <span>Открыто ({tier.minEfficiencyPct}%+)</span>
                          </span>
                        ) : (
                          <span className="text-zinc-500">
                            Нужно ещё +{tier.minEfficiencyPct - efficiencyInfo.pct}% эффективности (до {tier.minEfficiencyPct}%)
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-end gap-3">
              <button
                type="button"
                onClick={handleResetMonthlyProgress}
                className="min-h-[44px] px-4 py-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/40 text-xs font-semibold text-rose-300 flex items-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Сбросить весь прогресс месяца (0%)</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setReminders(getInitialReminders());
                  setTotalBucks(0);
                  showCoachMessage('billy', 'Базовое расписание восстановлено, прогресс на 0%!');
                }}
                className="min-h-[44px] px-4 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs font-medium text-zinc-300 flex items-center gap-2 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4 text-zinc-400" />
                <span>Восстановить базовые задачи (0%)</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Mobile Fixed Bottom Navigation Bar */}
      <nav
        aria-label="Нижняя навигация"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-30 bg-[#0f1115]/95 backdrop-blur-md border-t border-zinc-800 grid grid-cols-4 items-center h-16 px-2"
      >
        <button
          type="button"
          onClick={() => setActiveTab('schedule')}
          className={`min-h-[44px] flex flex-col items-center justify-center cursor-pointer ${
            activeTab === 'schedule' ? 'text-amber-400' : 'text-zinc-400'
          }`}
        >
          <Clock className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-1 whitespace-nowrap">
            Расписание
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('coaches')}
          className={`min-h-[44px] flex flex-col items-center justify-center cursor-pointer ${
            activeTab === 'coaches' ? 'text-amber-400' : 'text-zinc-400'
          }`}
        >
          <Users className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-1 whitespace-nowrap">
            Тренеры
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('soundboard')}
          className={`min-h-[44px] flex flex-col items-center justify-center cursor-pointer ${
            activeTab === 'soundboard' ? 'text-amber-400' : 'text-zinc-400'
          }`}
        >
          <Volume2 className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-1 whitespace-nowrap">
            Дека звуков
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('stats')}
          className={`min-h-[44px] flex flex-col items-center justify-center cursor-pointer ${
            activeTab === 'stats' ? 'text-amber-400' : 'text-zinc-400'
          }`}
        >
          <Award className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-1 whitespace-nowrap">
            Статистика
          </span>
        </button>
      </nav>

      {/* Offline Mode Toast */}
      <OfflineIndicator />

      {/* Create / Edit Reminder Bottom Sheet Modal */}
      <ReminderFormSheet
        isOpen={isFormOpen}
        editingReminder={editingReminder}
        selectedDateStr={selectedDateStr}
        categories={categories}
        coachesMap={coachesMap}
        customTracks={customTracks}
        onUploadCustomTrack={(file) => handleUploadCustomTrack(file)}
        onDeleteCustomTrack={handleDeleteCustomTrack}
        onOpenCategoryManager={() => setIsCategoryModalOpen(true)}
        onClose={() => {
          setIsFormOpen(false);
          setEditingReminder(null);
        }}
        onSave={handleSaveReminder}
      />

      {/* Category Editor Modal */}
      <CategoryManagerModal
        isOpen={isCategoryModalOpen}
        categories={categories}
        onClose={() => setIsCategoryModalOpen(false)}
        onUpdateCategories={(next) => setCategories(next)}
        onResetCategories={() => {
          setCategories(DEFAULT_CATEGORIES);
          showCoachMessage('billy', 'Восстановлены стандартные 5 рубрик!');
        }}
      />

      {/* Coach Creator & Photo/Voiceover Editor Modal */}
      <CoachCreatorModal
        isOpen={isCoachModalOpen}
        editingCoach={editingCoach}
        customTracks={customTracks}
        onUploadAudioFile={handleUploadCustomTrack}
        onClose={() => {
          setIsCoachModalOpen(false);
          setEditingCoach(null);
        }}
        onSaveCoach={(savedCoach) => {
          setCoachesMap((prev) => ({
            ...prev,
            [savedCoach.id]: savedCoach,
          }));
          setSelectedCoachId(savedCoach.id);
          showCoachMessage(
            savedCoach.id,
            `Настройки тренера «${savedCoach.name}» сохранены!`
          );
        }}
      />

      {/* Android Incoming Alarm Modal */}
      <AndroidAlarmModal
        reminder={activeAlarmReminder}
        coachesMap={coachesMap}
        categories={categories}
        defaultCustomTrackId={defaultSongObj?.id}
        defaultCustomTrackName={defaultSongObj?.name}
        completedCount={counts.completed}
        totalCount={counts.total}
        onComplete={handleToggleComplete}
        onSnooze={handleSnoozeReminder}
        onDismiss={() => {
          stopAlarmRinger();
          setActiveAlarmReminder(null);
        }}
      />
    </div>
  );
}
