import { SoundEffectId } from '../data/gachiData';
import { getAllCustomTracks, getCustomTrackById } from './customTracksDB';

let sharedAudioCtx: AudioContext | null = null;
let activeHtmlAudio: HTMLAudioElement | null = null;
let activeObjectUrl: string | null = null;
let activeVoiceAudio: HTMLAudioElement | null = null;
let activeVoiceObjectUrl: string | null = null;
let activeLoopInterval: number | null = null;
let activeVibrationInterval: number | null = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const AudioCtx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AudioCtx) return null;
  if (!sharedAudioCtx) {
    sharedAudioCtx = new AudioCtx();
  }
  if (sharedAudioCtx.state === 'suspended') {
    sharedAudioCtx.resume().catch(() => {});
  }
  return sharedAudioCtx;
}

export function triggerAndroidVibration(pattern: number | number[] = [180, 80, 220]) {
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate(pattern);
    } catch {
      // Ignore if vibration blocked
    }
  }
}

export function stopCoachVoiceover() {
  if (activeVoiceAudio) {
    try {
      activeVoiceAudio.pause();
      activeVoiceAudio.currentTime = 0;
      activeVoiceAudio.src = '';
    } catch {
      // Ignore
    }
    activeVoiceAudio = null;
  }
  if (activeVoiceObjectUrl) {
    URL.revokeObjectURL(activeVoiceObjectUrl);
    activeVoiceObjectUrl = null;
  }
}

export function stopAlarmRinger() {
  if (activeLoopInterval !== null) {
    window.clearInterval(activeLoopInterval);
    activeLoopInterval = null;
  }
  if (activeVibrationInterval !== null) {
    window.clearInterval(activeVibrationInterval);
    activeVibrationInterval = null;
  }
  if (activeHtmlAudio) {
    try {
      activeHtmlAudio.pause();
      activeHtmlAudio.currentTime = 0;
      activeHtmlAudio.src = '';
    } catch {
      // Ignore
    }
    activeHtmlAudio = null;
  }
  if (activeObjectUrl) {
    URL.revokeObjectURL(activeObjectUrl);
    activeObjectUrl = null;
  }
  stopCoachVoiceover();
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate(0);
    } catch {
      // Ignore
    }
  }
}

export async function playCoachVoiceover(
  voiceTrackId?: string,
  volume = 1.0
): Promise<boolean> {
  stopCoachVoiceover();
  if (!voiceTrackId) return false;
  try {
    const track = await getCustomTrackById(voiceTrackId);
    if (!track || !track.blob) return false;
    const url = URL.createObjectURL(track.blob);
    activeVoiceObjectUrl = url;
    const audio = new Audio(url);
    audio.volume = Math.max(0.1, Math.min(1, volume));
    activeVoiceAudio = audio;
    await audio.play();
    return true;
  } catch {
    return false;
  }
}

export async function playCustomTrackBlob(
  blob: Blob,
  loop = false,
  volume = 0.9
): Promise<boolean> {
  stopAlarmRinger();
  try {
    const url = URL.createObjectURL(blob);
    activeObjectUrl = url;
    const audio = new Audio(url);
    audio.loop = loop;
    audio.volume = Math.max(0.05, Math.min(1, volume));
    activeHtmlAudio = audio;
    await audio.play();
    return true;
  } catch {
    return false;
  }
}

export async function startAlarmRinger(options: {
  soundId: SoundEffectId;
  customTrackId?: string;
  coachVoiceTrackId?: string;
  volume?: number;
}): Promise<{ playingCustomSong: boolean; songName?: string; playingCoachVoice: boolean }> {
  stopAlarmRinger();
  const vol = options.volume ?? 0.85;

  // Periodic vibration for Android alarm feel
  triggerAndroidVibration([300, 150, 300, 150, 400]);
  activeVibrationInterval = window.setInterval(() => {
    triggerAndroidVibration([280, 120, 280]);
  }, 2600);

  // Trigger the coach's unique custom voiceover if assigned
  let playingCoachVoice = false;
  if (options.coachVoiceTrackId) {
    playingCoachVoice = await playCoachVoiceover(options.coachVoiceTrackId, 1.0);
  }

  // 1. Try playing the specific custom track assigned to this alarm
  if (options.customTrackId) {
    const customTrack = await getCustomTrackById(options.customTrackId);
    if (customTrack && customTrack.blob) {
      const url = URL.createObjectURL(customTrack.blob);
      activeObjectUrl = url;
      const audio = new Audio(url);
      audio.loop = true;
      audio.volume = playingCoachVoice ? Math.min(vol, 0.55) : vol;
      activeHtmlAudio = audio;
      try {
        await audio.play();
        return {
          playingCustomSong: true,
          songName: customTrack.name,
          playingCoachVoice,
        };
      } catch {
        // Fallback if play failed
      }
    }
  }

  // 2. If no specific track was assigned, check if the user uploaded a default song on their device
  const allTracks = await getAllCustomTracks();
  if (options.customTrackId === 'auto_first' && allTracks.length > 0) {
    const first = allTracks[0];
    const url = URL.createObjectURL(first.blob);
    activeObjectUrl = url;
    const audio = new Audio(url);
    audio.loop = true;
    audio.volume = playingCoachVoice ? Math.min(vol, 0.55) : vol;
    activeHtmlAudio = audio;
    try {
      await audio.play();
      return {
        playingCustomSong: true,
        songName: first.name,
        playingCoachVoice,
      };
    } catch {
      // Fallback
    }
  }

  // 3. Otherwise loop the built-in Gachi / F1 synthesizer ringtone continuously
  playGachiSound(options.soundId, playingCoachVoice ? 0.35 : vol);
  activeLoopInterval = window.setInterval(() => {
    playGachiSound(options.soundId, playingCoachVoice ? 0.35 : vol);
  }, 2100);

  return { playingCustomSong: false, playingCoachVoice };
}

export function playGachiSound(soundId: SoundEffectId, volume = 0.5) {
  const ctx = getAudioContext();
  if (!ctx) return;

  const now = ctx.currentTime;
  const master = ctx.createGain();
  master.gain.setValueAtTime(Math.max(0.05, Math.min(1, volume)), now);
  master.connect(ctx.destination);

  if (soundId === 'f1_pit_radio') {
    for (let i = 0; i < 5; i++) {
      const beepTime = now + i * 0.22;
      const beep = ctx.createOscillator();
      const beepGain = ctx.createGain();
      beep.type = 'square';
      beep.frequency.setValueAtTime(880, beepTime);
      beepGain.gain.setValueAtTime(0.35, beepTime);
      beepGain.gain.exponentialRampToValueAtTime(0.001, beepTime + 0.12);
      beep.connect(beepGain);
      beepGain.connect(master);
      beep.start(beepTime);
      beep.stop(beepTime + 0.13);
    }

    const revStart = now + 1.15;
    const v10A = ctx.createOscillator();
    const v10B = ctx.createOscillator();
    const filter = ctx.createBiquadFilter();
    const revGain = ctx.createGain();

    v10A.type = 'sawtooth';
    v10B.type = 'sawtooth';

    v10A.frequency.setValueAtTime(240, revStart);
    v10A.frequency.exponentialRampToValueAtTime(620, revStart + 0.35);
    v10A.frequency.setValueAtTime(460, revStart + 0.36);
    v10A.frequency.exponentialRampToValueAtTime(840, revStart + 0.8);

    v10B.frequency.setValueAtTime(360, revStart);
    v10B.frequency.exponentialRampToValueAtTime(930, revStart + 0.35);
    v10B.frequency.setValueAtTime(690, revStart + 0.36);
    v10B.frequency.exponentialRampToValueAtTime(1260, revStart + 0.8);

    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(900, revStart);
    filter.Q.setValueAtTime(1.2, revStart);

    revGain.gain.setValueAtTime(0.01, revStart);
    revGain.gain.linearRampToValueAtTime(0.55, revStart + 0.2);
    revGain.gain.exponentialRampToValueAtTime(0.001, revStart + 0.85);

    v10A.connect(filter);
    v10B.connect(filter);
    filter.connect(revGain);
    revGain.connect(master);

    v10A.start(revStart);
    v10B.start(revStart);
    v10A.stop(revStart + 0.88);
    v10B.stop(revStart + 0.88);
    return;
  }

  if (soundId === 'aniki_fanfare') {
    const notes = [261.63, 392.0, 523.25, 659.25, 783.99];
    const times = [0, 0.14, 0.28, 0.44, 0.6];
    const durations = [0.12, 0.12, 0.14, 0.14, 0.45];

    notes.forEach((freq, idx) => {
      const osc = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc2.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + times[idx]);
      osc2.frequency.setValueAtTime(freq * 0.5, now + times[idx]);

      gain.gain.setValueAtTime(0.001, now + times[idx]);
      gain.gain.exponentialRampToValueAtTime(0.5, now + times[idx] + 0.025);
      gain.gain.exponentialRampToValueAtTime(0.001, now + times[idx] + durations[idx]);

      osc.connect(gain);
      osc2.connect(gain);
      gain.connect(master);

      osc.start(now + times[idx]);
      osc2.start(now + times[idx]);
      osc.stop(now + times[idx] + durations[idx] + 0.02);
      osc2.stop(now + times[idx] + durations[idx] + 0.02);
    });
  } else if (soundId === 'dungeon_bell') {
    const partials = [196, 392, 587.33, 830.6, 1174.66];
    partials.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = i % 2 === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(freq, now);
      gain.gain.setValueAtTime(0.45 / (i + 1), now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 1.15);
      osc.connect(gain);
      gain.connect(master);
      osc.start(now);
      osc.stop(now + 1.2);
    });

    const sub = ctx.createOscillator();
    const subGain = ctx.createGain();
    sub.type = 'sawtooth';
    sub.frequency.setValueAtTime(110, now + 0.35);
    sub.frequency.exponentialRampToValueAtTime(55, now + 0.95);
    subGain.gain.setValueAtTime(0.4, now + 0.35);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 0.95);
    sub.connect(subGain);
    subGain.connect(master);
    sub.start(now + 0.35);
    sub.stop(now + 1.0);
  } else if (soundId === 'ricardo_bass') {
    const groove = [130.81, 164.81, 196.0, 261.63, 196.0, 246.94];
    groove.forEach((freq, i) => {
      const t = now + i * 0.13;
      const osc = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();
      const gain = ctx.createGain();

      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, t);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(950, t);
      filter.frequency.exponentialRampToValueAtTime(220, t + 0.11);

      gain.gain.setValueAtTime(0.55, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.12);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(master);

      osc.start(t);
      osc.stop(t + 0.125);
    });
  } else if (soundId === 'gym_whip') {
    const bufferSize = ctx.sampleRate * 0.25;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.04));
    }

    const noise = ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(1800, now);
    filter.Q.setValueAtTime(1.5, now);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.9, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.22);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(master);
    noise.start(now);

    const punch = ctx.createOscillator();
    const punchGain = ctx.createGain();
    punch.type = 'sine';
    punch.frequency.setValueAtTime(320, now);
    punch.frequency.exponentialRampToValueAtTime(60, now + 0.15);
    punchGain.gain.setValueAtTime(0.6, now);
    punchGain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
    punch.connect(punchGain);
    punchGain.connect(master);
    punch.start(now);
    punch.stop(now + 0.17);
  } else if (soundId === 'three_hundred_bucks') {
    const coins = [987.77, 1318.51, 1567.98, 1975.53];
    coins.forEach((freq, i) => {
      const t = now + i * 0.09;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.45, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
      osc.connect(gain);
      gain.connect(master);
      osc.start(t);
      osc.stop(t + 0.36);
    });
  } else if (soundId === 'power_chord') {
    const chord = [110, 164.81, 220, 329.63];
    chord.forEach((freq) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, now);
      osc.frequency.setValueAtTime(freq * 1.122, now + 0.26);
      gain.gain.setValueAtTime(0.28, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.78);
      osc.connect(gain);
      gain.connect(master);
      osc.start(now);
      osc.stop(now + 0.8);
    });
  }
}
