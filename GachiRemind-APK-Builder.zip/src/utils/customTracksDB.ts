export interface CustomAudioTrack {
  id: string;
  name: string;
  subtitle?: string;
  coachId?: string;
  sizeBytes: number;
  mimeType: string;
  createdAt: number;
  blob: Blob;
}

const DB_NAME = 'gachiremind_audio_db';
const DB_VERSION = 2;
const STORE_NAME = 'custom_tracks';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB not supported'));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function getAllCustomTracks(): Promise<CustomAudioTrack[]> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.getAll();
      req.onsuccess = () => {
        const list = (req.result as CustomAudioTrack[]) || [];
        list.sort((a, b) => b.createdAt - a.createdAt);
        resolve(list);
      };
      req.onerror = () => reject(req.error);
    });
  } catch {
    return [];
  }
}

export async function saveCustomTrack(
  file: File,
  customTitle?: string,
  coachId?: string
): Promise<CustomAudioTrack> {
  const cleanName = customTitle?.trim() || file.name.replace(/\.[^/.]+$/, '');
  const track: CustomAudioTrack = {
    id: `custom-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    name: cleanName,
    subtitle: 'Музыка с устройства',
    coachId: coachId || 'billy',
    sizeBytes: file.size,
    mimeType: file.type || 'audio/mpeg',
    createdAt: Date.now(),
    blob: file,
  };

  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req = store.put(track);
    req.onsuccess = () => resolve(track);
    req.onerror = () => reject(req.error);
  });
}

export async function saveMultipleCustomTracks(files: File[]): Promise<CustomAudioTrack[]> {
  const audioFiles = files.filter(
    (f) =>
      f.type.startsWith('audio/') ||
      /\.(mp3|wav|ogg|m4a|flac|aac|opus|webm)$/i.test(f.name)
  );
  if (audioFiles.length === 0) return [];

  const db = await openDB();
  const savedTracks: CustomAudioTrack[] = [];

  for (let i = 0; i < audioFiles.length; i++) {
    const file = audioFiles[i];
    const track: CustomAudioTrack = {
      id: `custom-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 7)}`,
      name: file.name.replace(/\.[^/.]+$/, ''),
      subtitle: 'Найдено на устройстве',
      coachId: 'billy',
      sizeBytes: file.size,
      mimeType: file.type || 'audio/mpeg',
      createdAt: Date.now() + i,
      blob: file,
    };

    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(track);
      req.onsuccess = () => {
        savedTracks.push(track);
        resolve();
      };
      req.onerror = () => reject(req.error);
    });
  }

  return savedTracks;
}

export async function deleteCustomTrack(id: string): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    const req = store.delete(id);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

export async function getCustomTrackById(id: string): Promise<CustomAudioTrack | null> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get(id);
      req.onsuccess = () => resolve((req.result as CustomAudioTrack) || null);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return null;
  }
}
