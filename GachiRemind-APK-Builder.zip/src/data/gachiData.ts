export type CoachId = string;

export type CategoryId = string;

export type RepeatType = 'once' | 'daily' | 'weekdays' | 'weekends';

export type SoundEffectId =
  | 'aniki_fanfare'
  | 'dungeon_bell'
  | 'ricardo_bass'
  | 'gym_whip'
  | 'three_hundred_bucks'
  | 'power_chord'
  | 'f1_pit_radio';

export type CoachAvatarPreset = 'billy' | 'van' | 'ricardo' | 'steve' | 'f1_pilot';

export interface CategoryItem {
  id: CategoryId;
  label: string;
  description: string;
}

export interface CoachProfile {
  id: CoachId;
  name: string;
  title: string;
  specialty: string;
  accentColor: string;
  defaultSound: SoundEffectId;
  defaultCustomTrackId?: string;
  voiceTrackId?: string;
  voiceTrackName?: string;
  avatarPreset: CoachAvatarPreset;
  customAvatarDataUrl?: string;
  isCustom?: boolean;
  alarmQuotes: string[];
  completionQuotes: string[];
  snoozeQuotes: string[];
  bio: string;
}

export interface ReminderItem {
  id: string;
  title: string;
  note: string;
  time: string; // HH:mm
  dateStr: string; // YYYY-MM-DD
  category: CategoryId;
  coachId: CoachId;
  soundId: SoundEffectId;
  customTrackId?: string;
  customTrackName?: string;
  repeat: RepeatType;
  rewardBucks: 100 | 300 | 500;
  completed: boolean;
  completedAt?: string;
  completedTimestamp?: number;
  snoozedCount: number;
}

export interface SoundPadItem {
  id: SoundEffectId;
  title: string;
  subtitle: string;
  phrase: string;
  coachId: CoachId;
  bpmLabel: string;
}

export interface RankTier {
  id: string;
  title: string;
  subtitle: string;
  minBucks: number;
  minEfficiencyPct: number;
  badgeLabel: string;
}

export const DEFAULT_CATEGORIES: CategoryItem[] = [
  { id: 'regime', label: 'Режим', description: 'Сон, подъём, питание и распорядок дня' },
  { id: 'tests', label: 'Проверочные', description: 'Контрольные, зачёты, тесты и экзамены' },
  { id: 'homework', label: 'ДЗ', description: 'Домашние задания, конспекты и проекты' },
  { id: 'gym', label: 'Качалка', description: 'Силовые тренировки, база и рабочие подходы' },
  { id: 'health', label: 'Здоровье', description: 'Вода, осанка, растяжка и восстановление' },
];

export const REPEAT_LABELS: Record<RepeatType, string> = {
  once: 'Один раз',
  daily: 'Каждый день',
  weekdays: 'По будням',
  weekends: 'По выходным',
};

export const DEFAULT_COACHES: Record<string, CoachProfile> = {
  billy: {
    id: 'billy',
    name: 'Билли «Аники»',
    title: 'Boss of This Gym',
    specialty: 'Режим, братская поддержка и тяжёлая база',
    accentColor: '#f59e0b',
    defaultSound: 'aniki_fanfare',
    avatarPreset: 'billy',
    bio: 'Легендарный наставник качалки. Поможет сдать любую проверочную и выжать последний повтор с улыбкой настоящего чемпиона.',
    alarmQuotes: [
      'Просыпайся, чемпион! Качалка и дела сами себя не закроют — пора показать, кто здесь Босс!',
      'Эй, братишка! Время выполнить обещание. Раздевалка ждёт твоего рекорда!',
    ],
    completionQuotes: [
      'Красавчик, Аники гордится тобой! Заслуженные баксы в копилку Босса!',
      'Вот это мощь! Чистое исполнение на скорости болида!',
    ],
    snoozeQuotes: [
      'Ладно, 10 минут пит-стопа между подходами, но потом без отговорок!',
    ],
  },
  van: {
    id: 'van',
    name: 'Ван «Мастер»',
    title: 'Dungeon Master',
    specialty: 'ДЗ без списывания, проверочные и железная дисциплина',
    accentColor: '#e11d48',
    defaultSound: 'dungeon_bell',
    avatarPreset: 'van',
    bio: 'Строгий хранитель подземелья дисциплины. Не терпит невыполненной домашки, пропусков и оправданий. За каждую закрытую задачу начисляет 300 Bucks.',
    alarmQuotes: [
      'Время вышло, Jabroni! Ты думал пропустить ДЗ или проверочную в моём расписании? За работу!',
      'Deep Dark Fantasies подождут — сначала закрой эту задачу как положено!',
    ],
    completionQuotes: [
      'Достойно. Держи свои 300 Bucks, сегодня ты доказал свой уровень.',
      'Задача закрыта без лишних слов. Настоящая выдержка Мастера.',
    ],
    snoozeQuotes: [
      'Откладываешь? Десять минут штрафного круга — и за дело!',
    ],
  },
  ricardo: {
    id: 'ricardo',
    name: 'Рикардо «Флекс»',
    title: 'Cardio & Vibe King',
    specialty: 'Здоровье, разминка между уроками и бодрый ритм',
    accentColor: '#ef4444',
    defaultSound: 'ricardo_bass',
    avatarPreset: 'ricardo',
    bio: 'Король ритма и взрывного кардио в красной бандане. Превращает любой будильник и подготовку к проверочной в победный заезд.',
    alarmQuotes: [
      'Врубай свою песню на полную! Пора двигаться и разносить этот день!',
      'Почувствуй этот ритм! Вставай со стула, разомни спину и сделай красиво!',
    ],
    completionQuotes: [
      'Идеальный ритм! Энергия зашкаливает, продолжаем держать темп!',
    ],
    snoozeQuotes: [
      'Короткий пит-стоп на воду, и возвращаемся на трассу!',
    ],
  },
  steve: {
    id: 'steve',
    name: 'Стив «Рэмбо»',
    title: 'Tactical & F1 Pit Boss',
    specialty: 'Утренние подъёмы по будильнику, режим и реакция',
    accentColor: '#10b981',
    defaultSound: 'f1_pit_radio',
    avatarPreset: 'steve',
    bio: 'Мастер полевой подготовки и быстрых пит-стопов за 1.9 секунды. Отвечает за точный подъём по будильнику и подготовку к контрольным.',
    alarmQuotes: [
      'Box, box! Пять красных огней погасли — стартуй к своей задаче немедленно!',
      'Тактический будильник! Пора закрыть пункт плана на поул-позиции!',
    ],
    completionQuotes: [
      'Лучший круг дня! Тактическая задача выполнена на сто процентов!',
    ],
    snoozeQuotes: [
      'Меняем шины на софт — 10 минут до рестарта!',
    ],
  },
};

export const SOUND_PADS: SoundPadItem[] = [
  {
    id: 'aniki_fanfare',
    title: 'Гимн Аники',
    subtitle: 'Героические золотые аккорды качалки',
    phrase: 'Сигнал чемпиона качалки',
    coachId: 'billy',
    bpmLabel: '128 BPM · Synth Brass',
  },
  {
    id: 'dungeon_bell',
    title: 'Колокол Раздевалки',
    subtitle: 'Тяжёлый удар гонга и басовый рифф',
    phrase: 'Тяжёлый гонг дисциплины',
    coachId: 'van',
    bpmLabel: '110 BPM · Heavy Gong',
  },
  {
    id: 'ricardo_bass',
    title: 'Флекс-Бас Рикардо',
    subtitle: 'Пульсирующий танцевальный электро-бит',
    phrase: 'Танцевальный бас-ритм',
    coachId: 'ricardo',
    bpmLabel: '136 BPM · Club Bass',
  },
  {
    id: 'f1_pit_radio',
    title: 'F1 Старт & V10 Пит-стоп',
    subtitle: '5 стартовых огней Гран-при и рёв мотора Формулы-1',
    phrase: 'Lights out and away we go! Box, box!',
    coachId: 'steve',
    bpmLabel: 'Formula 1 · V10 Telemetry',
  },
  {
    id: 'gym_whip',
    title: 'Щелчок Ремня',
    subtitle: 'Резкий звуковой импульс для дисциплины',
    phrase: 'Звуковой импульс без пощады к лени',
    coachId: 'van',
    bpmLabel: 'Impulse · Crisp Snap',
  },
  {
    id: 'three_hundred_bucks',
    title: 'Касса 300 Bucks',
    subtitle: 'Звон монет и победный синтезатор',
    phrase: 'Начисление 300 Bucks за подход',
    coachId: 'billy',
    bpmLabel: 'Reward · Coin Chime',
  },
  {
    id: 'power_chord',
    title: 'Тактический Овердрайв',
    subtitle: 'Мощный гитарный рифф 90-х',
    phrase: 'Мощный рок-аккорд 90-х',
    coachId: 'steve',
    bpmLabel: '140 BPM · Overdrive',
  },
];

// 15 Full Monthly Ranks of the Locker Room & Grand Prix Paddock
// Highest rank (Rank 15) requires >= 95% Efficiency Coefficient (КЭ >= 0.95)
export const RANK_TIERS: RankTier[] = [
  {
    id: 'rank_1',
    title: 'Jabroni · Стажёр Раздевалки',
    subtitle: 'Старт нового месяца: переступил порог качалки и готовится к заезду',
    minBucks: 0,
    minEfficiencyPct: 0,
    badgeLabel: 'Ранг 1 из 15',
  },
  {
    id: 'rank_2',
    title: 'Дежурный по Гантелям',
    subtitle: 'Не забывает ставить блины на место и просыпается с первого будильника',
    minBucks: 100,
    minEfficiencyPct: 7,
    badgeLabel: 'Ранг 2 из 15',
  },
  {
    id: 'rank_3',
    title: 'Новичок Стартовой Решётки (Rookie)',
    subtitle: 'Прошёл прогревочный круг и начал вовремя закрывать ДЗ',
    minBucks: 250,
    minEfficiencyPct: 14,
    badgeLabel: 'Ранг 3 из 15',
  },
  {
    id: 'rank_4',
    title: 'Любитель Железа и Протеина',
    subtitle: 'Соблюдает режим сна и держит стабильный рабочий вес',
    minBucks: 450,
    minEfficiencyPct: 21,
    badgeLabel: 'Ранг 4 из 15',
  },
  {
    id: 'rank_5',
    title: 'Механик Пит-стопа (1.9 сек)',
    subtitle: 'Мгновенная реакция на будильник без кнопки «Отложить»',
    minBucks: 700,
    minEfficiencyPct: 28,
    badgeLabel: 'Ранг 5 из 15',
  },
  {
    id: 'rank_6',
    title: 'Укротитель Проверочных',
    subtitle: 'Сдаёт контрольные и зачёты с первой попытки без шпаргалок',
    minBucks: 950,
    minEfficiencyPct: 35,
    badgeLabel: 'Ранг 6 из 15',
  },
  {
    id: 'rank_7',
    title: 'Leather Club Regular',
    subtitle: 'Постоянный резидент клуба дисциплины и уважения братвы',
    minBucks: 1200,
    minEfficiencyPct: 42,
    badgeLabel: 'Ранг 7 из 15',
  },
  {
    id: 'rank_8',
    title: 'Мастер Флекса Рикардо',
    subtitle: 'Несгибаемая осанка, стальное здоровье и бодрый ритм каждый день',
    minBucks: 1500,
    minEfficiencyPct: 50,
    badgeLabel: 'Ранг 8 из 15',
  },
  {
    id: 'rank_9',
    title: 'Тактический Выживший (Catalina Pro)',
    subtitle: 'Ни один дедлайн по ДЗ или тренировке не застанет врасплох',
    minBucks: 1850,
    minEfficiencyPct: 58,
    badgeLabel: 'Ранг 9 из 15',
  },
  {
    id: 'rank_10',
    title: 'Пилот Поул-Позиции (P1 Qualifier)',
    subtitle: 'Всегда стартует первым в расписании дня на максимальных оборотах V10',
    minBucks: 2200,
    minEfficiencyPct: 65,
    badgeLabel: 'Ранг 10 из 15',
  },
  {
    id: 'rank_11',
    title: 'Хранитель Золотого Пояса (300 Bucks Elite)',
    subtitle: 'Эталон режима, силы и выдержки для всей раздевалки',
    minBucks: 2600,
    minEfficiencyPct: 72,
    badgeLabel: 'Ранг 11 из 15',
  },
  {
    id: 'rank_12',
    title: 'Dungeon Master',
    subtitle: 'Верховный мастер сложных задач, тяжёлой базы и железного порядка',
    minBucks: 3000,
    minEfficiencyPct: 78,
    badgeLabel: 'Ранг 12 из 15',
  },
  {
    id: 'rank_13',
    title: 'Победитель Гран-При Качалки',
    subtitle: 'Забирает кубок дисциплины и шампанское на подиуме каждой недели',
    minBucks: 3500,
    minEfficiencyPct: 84,
    badgeLabel: 'Ранг 13 из 15',
  },
  {
    id: 'rank_14',
    title: 'Наследник Аники (Golden Legend)',
    subtitle: 'Непоколебимый дух, братская мощь и высокий темп на дистанции месяца',
    minBucks: 4000,
    minEfficiencyPct: 90,
    badgeLabel: 'Ранг 14 из 15',
  },
  {
    id: 'rank_15',
    title: 'Boss of This Gym · Абсолютный Чемпион Мира',
    subtitle: 'Высший ранг месяца! Требуется коэффициент эффективности не менее 95% (КЭ ≥ 0.95)',
    minBucks: 4500,
    minEfficiencyPct: 95,
    badgeLabel: 'Ранг 15 из 15 · MAX (95%+)',
  },
];

export interface QuickTemplate {
  title: string;
  note: string;
  category: CategoryId;
  coachId: CoachId;
  soundId: SoundEffectId;
  rewardBucks: 100 | 300 | 500;
  defaultTimeOffsetMin: number;
}

export const QUICK_TEMPLATES: QuickTemplate[] = [
  {
    title: 'Подъём по будильнику и стакан воды',
    note: 'Встать с первого сигнала как на пит-стопе Ф1 и запустить метаболизм',
    category: 'regime',
    coachId: 'billy',
    soundId: 'aniki_fanfare',
    rewardBucks: 300,
    defaultTimeOffsetMin: 10,
  },
  {
    title: 'Подготовка к проверочной работе',
    note: 'Повторить билеты, формулы и ключевые темы за 40 минут интенсивного фокуса',
    category: 'tests',
    coachId: 'van',
    soundId: 'dungeon_bell',
    rewardBucks: 500,
    defaultTimeOffsetMin: 25,
  },
  {
    title: 'Сделать ДЗ без прокрастинации',
    note: 'Убрать телефон, решить все задачи и собрать сумку на завтра',
    category: 'homework',
    coachId: 'van',
    soundId: 'gym_whip',
    rewardBucks: 300,
    defaultTimeOffsetMin: 40,
  },
  {
    title: 'Силовая тренировка в качалке',
    note: 'Разминка суставов, 4 рабочих подхода базы и заминка как у Босса',
    category: 'gym',
    coachId: 'billy',
    soundId: 'aniki_fanfare',
    rewardBucks: 500,
    defaultTimeOffsetMin: 60,
  },
  {
    title: 'Разминка спины и шеи (Пит-стоп Здоровья)',
    note: '15 минут растяжки грудного отдела под старт Гран-при',
    category: 'health',
    coachId: 'steve',
    soundId: 'f1_pit_radio',
    rewardBucks: 100,
    defaultTimeOffsetMin: 30,
  },
];

export function getTodayDateStr(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function getCurrentMonthKey(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  return `${y}-${m}`;
}

export function getCurrentMonthLabel(): string {
  const months = [
    'Январь',
    'Февраль',
    'Март',
    'Апрель',
    'Май',
    'Июнь',
    'Июль',
    'Август',
    'Сентябрь',
    'Октябрь',
    'Ноябрь',
    'Декабрь',
  ];
  const now = new Date();
  return `${months[now.getMonth()]} ${now.getFullYear()}`;
}

export function getInitialReminders(): ReminderItem[] {
  const today = getTodayDateStr();
  const now = new Date();

  const formatTimeOffset = (offsetMinutes: number) => {
    const target = new Date(now.getTime() + offsetMinutes * 60000);
    return `${String(target.getHours()).padStart(2, '0')}:${String(target.getMinutes()).padStart(2, '0')}`;
  };

  return [
    {
      id: 'rem-1',
      title: 'Утренний будильник чемпиона и зарядка',
      note: 'Старт дня с поул-позиции, стакан воды и 25 отжиманий',
      time: '07:30',
      dateStr: today,
      category: 'regime',
      coachId: 'ricardo',
      soundId: 'ricardo_bass',
      repeat: 'daily',
      rewardBucks: 300,
      completed: false,
      snoozedCount: 0,
    },
    {
      id: 'rem-2',
      title: 'Повторить материал перед проверочной',
      note: 'Разобрать сложные задания и формулы, чтобы сдать на максимум',
      time: formatTimeOffset(10),
      dateStr: today,
      category: 'tests',
      coachId: 'van',
      soundId: 'dungeon_bell',
      repeat: 'weekdays',
      rewardBucks: 500,
      completed: false,
      snoozedCount: 0,
    },
    {
      id: 'rem-3',
      title: 'Выполнить ДЗ на завтра',
      note: 'Закрыть все письменные задания за 45 минут чистого фокуса',
      time: formatTimeOffset(35),
      dateStr: today,
      category: 'homework',
      coachId: 'billy',
      soundId: 'aniki_fanfare',
      repeat: 'weekdays',
      rewardBucks: 300,
      completed: false,
      snoozedCount: 0,
    },
    {
      id: 'rem-4',
      title: 'Вечерняя база в качалке (Спина и Грудь)',
      note: 'Подтягивания, жим лёжа 4x10 и протеиновый коктейль после зала',
      time: '19:30',
      dateStr: today,
      category: 'gym',
      coachId: 'billy',
      soundId: 'aniki_fanfare',
      repeat: 'weekdays',
      rewardBucks: 500,
      completed: false,
      snoozedCount: 0,
    },
    {
      id: 'rem-5',
      title: 'Пит-стоп для спины и шеи',
      note: 'Снять напряжение после учёбы за столом и выпить стакан чистой воды',
      time: '21:30',
      dateStr: today,
      category: 'health',
      coachId: 'steve',
      soundId: 'f1_pit_radio',
      repeat: 'daily',
      rewardBucks: 100,
      completed: false,
      snoozedCount: 0,
    },
  ];
}
