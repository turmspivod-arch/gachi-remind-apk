import React, { useEffect, useRef, useState } from 'react';
import {
  Camera,
  Mic,
  Play,
  Plus,
  RotateCcw,
  Square,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import {
  CategoryItem,
  CoachAvatarPreset,
  CoachProfile,
  SOUND_PADS,
  SoundEffectId,
} from '../data/gachiData';
import { playCoachVoiceover, stopCoachVoiceover } from '../utils/gachiAudio';
import { CustomAudioTrack } from '../utils/customTracksDB';
import { CoachAvatar } from './GachiArtwork';

interface CategoryManagerModalProps {
  isOpen: boolean;
  categories: CategoryItem[];
  onClose: () => void;
  onUpdateCategories: (next: CategoryItem[]) => void;
  onResetCategories: () => void;
}

export const CategoryManagerModal: React.FC<CategoryManagerModalProps> = ({
  isOpen,
  categories,
  onClose,
  onUpdateCategories,
  onResetCategories,
}) => {
  const [newLabel, setNewLabel] = useState('');
  const [newDesc, setNewDesc] = useState('');

  if (!isOpen) return null;

  const handleRenameCategory = (id: string, label: string) => {
    onUpdateCategories(
      categories.map((cat) => (cat.id === id ? { ...cat, label } : cat))
    );
  };

  const handleDeleteCategory = (id: string) => {
    if (categories.length <= 1) return;
    onUpdateCategories(categories.filter((cat) => cat.id !== id));
  };

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = newLabel.trim();
    if (!clean) return;
    const newItem: CategoryItem = {
      id: `cat-${Date.now()}`,
      label: clean,
      description: newDesc.trim() || 'Пользовательская рубрика',
    };
    onUpdateCategories([...categories, newItem]);
    setNewLabel('');
    setNewDesc('');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="cat-modal-title"
    >
      <div className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-3xl bg-zinc-900 border border-zinc-800 p-6 shadow-2xl space-y-5">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h2
              id="cat-modal-title"
              className="text-xl font-bold text-white font-display uppercase tracking-wide"
            >
              Редактировать рубрики
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              Переименуй существующие рубрики, удали лишние или добавь свои
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] min-w-[44px] rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 flex items-center justify-center cursor-pointer"
            aria-label="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Existing Categories List */}
        <div className="space-y-2.5">
          {categories.map((cat) => (
            <div
              key={cat.id}
              className="flex items-center gap-2 p-2.5 rounded-2xl bg-zinc-950 border border-zinc-800"
            >
              <input
                type="text"
                value={cat.label}
                onChange={(e) => handleRenameCategory(cat.id, e.target.value)}
                className="flex-1 min-h-[40px] px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-500"
                aria-label={`Название рубрики ${cat.label}`}
              />
              {categories.length > 1 && (
                <button
                  type="button"
                  onClick={() => handleDeleteCategory(cat.id)}
                  className="min-h-[40px] min-w-[40px] rounded-xl bg-zinc-900 hover:bg-rose-950/60 text-zinc-400 hover:text-rose-400 flex items-center justify-center cursor-pointer shrink-0"
                  aria-label={`Удалить рубрику ${cat.label}`}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          ))}
        </div>

        {/* Add New Category Form */}
        <form
          onSubmit={handleAddCategory}
          className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-3"
        >
          <div className="text-xs font-semibold text-amber-400">
            Добавить новую рубрику
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <input
              type="text"
              value={newLabel}
              onChange={(e) => setNewLabel(e.target.value)}
              placeholder="Название (напр. Гран-при / Экзамен)"
              className="min-h-[42px] px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
            />
            <input
              type="text"
              value={newDesc}
              onChange={(e) => setNewDesc(e.target.value)}
              placeholder="Описание (необязательно)"
              className="min-h-[42px] px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
            />
          </div>
          <button
            type="submit"
            className="w-full min-h-[42px] rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Добавить рубрику</span>
          </button>
        </form>

        <div className="flex items-center justify-between gap-3 pt-2">
          <button
            type="button"
            onClick={onResetCategories}
            className="min-h-[44px] px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-medium flex items-center gap-1.5 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Вернуть стандартные 5 рубрик</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold cursor-pointer"
          >
            Готово
          </button>
        </div>
      </div>
    </div>
  );
};

interface CoachCreatorModalProps {
  isOpen: boolean;
  editingCoach: CoachProfile | null;
  customTracks: CustomAudioTrack[];
  onUploadAudioFile: (file: File, customTitle?: string) => Promise<CustomAudioTrack | null>;
  onClose: () => void;
  onSaveCoach: (coach: CoachProfile) => void;
}

export const CoachCreatorModal: React.FC<CoachCreatorModalProps> = ({
  isOpen,
  editingCoach,
  customTracks,
  onUploadAudioFile,
  onClose,
  onSaveCoach,
}) => {
  const [name, setName] = useState('');
  const [title, setTitle] = useState('Гоночный Инженер & Босс');
  const [specialty, setSpecialty] = useState('Пит-стопы, ДЗ и тяжёлая база');
  const [bio, setBio] = useState('');
  const [alarmQuote, setAlarmQuote] = useState(
    'Box, box! Время закрыть задачу на максимальной скорости!'
  );
  const [completionQuote, setCompletionQuote] = useState(
    'Лучший круг! +300 Bucks зачислены!'
  );
  const [avatarPreset, setAvatarPreset] = useState<CoachAvatarPreset>('f1_pilot');
  const [customAvatarDataUrl, setCustomAvatarDataUrl] = useState<string | undefined>(
    undefined
  );
  const [defaultSound, setDefaultSound] = useState<SoundEffectId>('f1_pit_radio');
  const [defaultCustomTrackId, setDefaultCustomTrackId] = useState<string | undefined>(
    undefined
  );
  const [voiceTrackId, setVoiceTrackId] = useState<string | undefined>(undefined);
  const [voiceTrackName, setVoiceTrackName] = useState<string | undefined>(undefined);

  // Microphone voice recording state
  const [isRecordingMic, setIsRecordingMic] = useState(false);
  const [micError, setMicError] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);

  const avatarInputRef = useRef<HTMLInputElement | null>(null);
  const voiceFileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (editingCoach) {
      setName(editingCoach.name);
      setTitle(editingCoach.title);
      setSpecialty(editingCoach.specialty);
      setBio(editingCoach.bio);
      setAlarmQuote(editingCoach.alarmQuotes[0] || '');
      setCompletionQuote(editingCoach.completionQuotes[0] || '');
      setAvatarPreset(editingCoach.avatarPreset || 'billy');
      setCustomAvatarDataUrl(editingCoach.customAvatarDataUrl);
      setDefaultSound(editingCoach.defaultSound);
      setDefaultCustomTrackId(editingCoach.defaultCustomTrackId);
      setVoiceTrackId(editingCoach.voiceTrackId);
      setVoiceTrackName(editingCoach.voiceTrackName);
    } else {
      setName('');
      setTitle('Гоночный Инженер & Босс');
      setSpecialty('Пит-стопы, ДЗ и тяжёлая база');
      setBio('');
      setAlarmQuote('Box, box! Время закрыть задачу на максимальной скорости!');
      setCompletionQuote('Лучший круг! +300 Bucks зачислены!');
      setAvatarPreset('f1_pilot');
      setCustomAvatarDataUrl(undefined);
      setDefaultSound('f1_pit_radio');
      setDefaultCustomTrackId(undefined);
      setVoiceTrackId(undefined);
      setVoiceTrackName(undefined);
    }
    setMicError(null);
    setIsRecordingMic(false);
  }, [editingCoach, isOpen]);

  useEffect(() => {
    if (!isOpen) {
      stopCoachVoiceover();
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setCustomAvatarDataUrl(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleVoiceFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const label = `Озвучка: ${file.name.replace(/\.[^/.]+$/, '')}`;
    const saved = await onUploadAudioFile(file, label);
    if (saved) {
      setVoiceTrackId(saved.id);
      setVoiceTrackName(saved.name);
      await playCoachVoiceover(saved.id, 1.0);
    }
    e.target.value = '';
  };

  const handleToggleMicRecord = async () => {
    setMicError(null);
    if (isRecordingMic) {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
        mediaRecorderRef.current.stop();
      }
      setIsRecordingMic(false);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      recordedChunksRef.current = [];
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) {
          recordedChunksRef.current.push(ev.data);
        }
      };

      recorder.onstop = async () => {
        stream.getTracks().forEach((tr) => tr.stop());
        const blob = new Blob(recordedChunksRef.current, { type: 'audio/webm' });
        const coachLabel = name.trim() || editingCoach?.name || 'Тренер';
        const file = new File([blob], `Озвучка_${coachLabel}.webm`, {
          type: 'audio/webm',
        });
        const saved = await onUploadAudioFile(file, `Озвучка (${coachLabel})`);
        if (saved) {
          setVoiceTrackId(saved.id);
          setVoiceTrackName(saved.name);
          await playCoachVoiceover(saved.id, 1.0);
        }
      };

      recorder.start();
      setIsRecordingMic(true);
    } catch {
      setMicError(
        'Доступ к микрофону запрещён в браузере — используй кнопку «Загрузить файл озвучки».'
      );
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    stopCoachVoiceover();
    const cleanName = name.trim() || 'Макс «Поул-Позиция»';
    const savedCoach: CoachProfile = {
      id: editingCoach ? editingCoach.id : `coach-${Date.now()}`,
      name: cleanName,
      title: title.trim() || 'Наставник раздевалки',
      specialty: specialty.trim() || 'Дисциплина и режим',
      accentColor: editingCoach?.accentColor || '#f59e0b',
      defaultSound,
      defaultCustomTrackId,
      voiceTrackId,
      voiceTrackName,
      avatarPreset,
      customAvatarDataUrl,
      isCustom: editingCoach ? editingCoach.isCustom : true,
      bio:
        bio.trim() ||
        'Наставник раздевалки и гоночного паддока. Следит за твоим расписанием и проверочными.',
      alarmQuotes: [
        alarmQuote.trim() || 'Время выполнить задачу без отговорок!',
      ],
      completionQuotes: [
        completionQuote.trim() || 'Отличная работа! Держи заслуженные Bucks!',
      ],
      snoozeQuotes: ['Десять минут пит-стопа — и возвращаемся к делу!'],
    };
    onSaveCoach(savedCoach);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="coach-modal-title"
    >
      <div className="w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-3xl bg-zinc-900 border border-zinc-800 p-6 shadow-2xl space-y-5">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h2
              id="coach-modal-title"
              className="text-xl font-bold text-white font-display uppercase tracking-wide"
            >
              {editingCoach
                ? `Настроить тренера: ${editingCoach.name}`
                : 'Добавить собственного тренера'}
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              Поставь любое фото с устройства и привяжи уникальную аудио-озвучку к этому тренеру
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              stopCoachVoiceover();
              onClose();
            }}
            className="min-h-[44px] min-w-[44px] rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 flex items-center justify-center cursor-pointer"
            aria-label="Закрыть"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* 1. Coach Photo & Avatar Selection */}
          <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <span className="text-xs font-semibold text-white block">
                  Фотография тренера
                </span>
                <span className="text-[11px] text-zinc-400">
                  Загрузи своё изображение с телефона/ПК или выбери стиль
                </span>
              </div>
              <input
                ref={avatarInputRef}
                type="file"
                accept="image/*"
                onChange={handleAvatarUpload}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => avatarInputRef.current?.click()}
                className="min-h-[40px] px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Camera className="w-4 h-4" />
                <span>Загрузить фото с устройства</span>
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              {(
                [
                  { id: 'f1_pilot', label: 'Пилот Ф1' },
                  { id: 'billy', label: 'Аники' },
                  { id: 'van', label: 'Мастер' },
                  { id: 'ricardo', label: 'Флекс' },
                  { id: 'steve', label: 'Тактик' },
                ] as const
              ).map((p) => {
                const isSelected = !customAvatarDataUrl && avatarPreset === p.id;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      setCustomAvatarDataUrl(undefined);
                      setAvatarPreset(p.id);
                    }}
                    className={`p-2 rounded-2xl border flex flex-col items-center gap-1 cursor-pointer ${
                      isSelected
                        ? 'bg-zinc-800 border-amber-500'
                        : 'bg-zinc-900 border-zinc-800'
                    }`}
                  >
                    <CoachAvatar presetOverride={p.id} size="sm" />
                    <span className="text-[10px] text-zinc-300">{p.label}</span>
                  </button>
                );
              })}

              {customAvatarDataUrl && (
                <div className="p-2 rounded-2xl border border-amber-500 bg-zinc-800 flex items-center gap-2.5">
                  <img
                    src={customAvatarDataUrl}
                    alt="Загруженное фото тренера"
                    className="w-12 h-12 rounded-xl object-cover"
                  />
                  <div>
                    <div className="text-xs font-semibold text-amber-400">
                      Фото установлено
                    </div>
                    <button
                      type="button"
                      onClick={() => setCustomAvatarDataUrl(undefined)}
                      className="text-[11px] text-zinc-400 hover:text-rose-400 underline cursor-pointer"
                    >
                      Сбросить фото
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* 2. Unique Voiceover per Coach (Upload Audio File OR Record Microphone) */}
          <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                  <Mic className="w-4 h-4 text-amber-400" />
                  <span>Уникальная озвучка тренера</span>
                </div>
                <p className="text-[11px] text-zinc-400 mt-0.5">
                  Загрузи голосовую фразу (MP3/WAV/OGG) или запиши на микрофон — она прозвучит на будильнике этого тренера
                </p>
              </div>
            </div>

            <input
              ref={voiceFileInputRef}
              type="file"
              accept="audio/*"
              onChange={handleVoiceFileUpload}
              className="hidden"
            />

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => voiceFileInputRef.current?.click()}
                className="min-h-[42px] px-3.5 py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-xs font-semibold text-amber-300 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                <span>Загрузить файл озвучки</span>
              </button>

              <button
                type="button"
                onClick={handleToggleMicRecord}
                className={`min-h-[42px] px-3.5 py-2 rounded-xl text-xs font-bold flex items-center justify-center gap-2 border cursor-pointer ${
                  isRecordingMic
                    ? 'bg-rose-600 text-white border-rose-500'
                    : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border-zinc-800'
                }`}
              >
                {isRecordingMic ? (
                  <>
                    <Square className="w-3.5 h-3.5 fill-current" />
                    <span>Остановить запись</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4 text-rose-400" />
                    <span>Записать с микрофона</span>
                  </>
                )}
              </button>
            </div>

            {micError && (
              <p className="text-xs text-rose-400">{micError}</p>
            )}

            {/* Select from existing uploaded audio tracks or preview current voiceover */}
            <div className="flex flex-col sm:flex-row sm:items-center gap-2 pt-1">
              <select
                value={voiceTrackId || ''}
                onChange={(e) => {
                  const id = e.target.value || undefined;
                  setVoiceTrackId(id);
                  const found = customTracks.find((t) => t.id === id);
                  setVoiceTrackName(found?.name);
                }}
                className="flex-1 min-h-[40px] px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs text-white focus:outline-none focus:border-amber-500"
              >
                <option value="">Без отдельной голосовой дорожки</option>
                {customTracks.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>

              {voiceTrackId && (
                <button
                  type="button"
                  onClick={() => playCoachVoiceover(voiceTrackId, 1.0)}
                  className="min-h-[40px] px-3.5 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Прослушать озвучку</span>
                </button>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-1">
                Имя тренера
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Напр.: Билли «Аники» / Макс Ферстаппен"
                className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-1">
                Титул / Звание
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Grand Prix Boss / Gym Master"
                className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-1">
              Специализация и описание
            </label>
            <input
              type="text"
              value={specialty}
              onChange={(e) => setSpecialty(e.target.value)}
              placeholder="ДЗ за 2 секунды, проверочные и жим лёжа"
              className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-1">
              Фраза на экране будильника
            </label>
            <input
              type="text"
              value={alarmQuote}
              onChange={(e) => setAlarmQuote(e.target.value)}
              className="w-full min-h-[44px] px-3.5 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-500"
            />
          </div>

          {/* Default Sound or Custom Song for this Coach */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-1">
                Стандартный рингтон тренера
              </label>
              <select
                value={defaultSound}
                onChange={(e) => setDefaultSound(e.target.value as SoundEffectId)}
                className="w-full min-h-[44px] px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white focus:outline-none focus:border-amber-500"
              >
                {SOUND_PADS.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.title}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-1">
                Песня тренера с устройства
              </label>
              <select
                value={defaultCustomTrackId || ''}
                onChange={(e) => setDefaultCustomTrackId(e.target.value || undefined)}
                className="w-full min-h-[44px] px-3 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-white focus:outline-none focus:border-amber-500"
              >
                <option value="">Использовать стандартный сигнал</option>
                {customTracks.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => {
                stopCoachVoiceover();
                onClose();
              }}
              className="min-h-[44px] px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium cursor-pointer"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="min-h-[44px] px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold cursor-pointer"
            >
              Сохранить тренера
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
