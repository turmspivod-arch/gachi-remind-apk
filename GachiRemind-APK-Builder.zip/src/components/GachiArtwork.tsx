import React from 'react';
import { Flag, Flame } from 'lucide-react';
import { CoachAvatarPreset, CoachProfile, DEFAULT_COACHES } from '../data/gachiData';

interface CoachAvatarProps {
  coachId?: string;
  coach?: CoachProfile;
  presetOverride?: CoachAvatarPreset;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export const CoachAvatar: React.FC<CoachAvatarProps> = ({
  coachId = 'billy',
  coach,
  presetOverride,
  size = 'md',
  className = '',
}) => {
  const dims = {
    sm: 'w-10 h-10',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24',
  }[size];

  const resolvedCoach = coach || DEFAULT_COACHES[coachId] || DEFAULT_COACHES.billy;

  if (resolvedCoach?.customAvatarDataUrl && !presetOverride) {
    return (
      <div
        className={`${dims} rounded-2xl overflow-hidden bg-zinc-900 border border-amber-500/40 shrink-0 flex items-center justify-center relative ${className}`}
      >
        <img
          src={resolvedCoach.customAvatarDataUrl}
          alt={resolvedCoach.name}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover"
        />
      </div>
    );
  }

  const preset: CoachAvatarPreset =
    presetOverride || resolvedCoach?.avatarPreset || 'billy';

  if (preset === 'f1_pilot') {
    return (
      <div
        className={`${dims} rounded-2xl overflow-hidden bg-zinc-900 border border-red-500/40 shrink-0 flex items-center justify-center relative ${className}`}
        aria-label="Портрет пилота Ф1"
      >
        <svg viewBox="0 0 120 120" className="w-full h-full">
          <defs>
            <linearGradient id="f1Bg" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#450a0a" />
              <stop offset="100%" stopColor="#09090b" />
            </linearGradient>
          </defs>
          <rect width="120" height="120" fill="url(#f1Bg)" />
          <rect x="0" y="0" width="120" height="6" fill="#ef4444" />
          <rect x="20" y="0" width="20" height="6" fill="#ffffff" />
          <rect x="60" y="0" width="20" height="6" fill="#ffffff" />
          <rect x="100" y="0" width="20" height="6" fill="#ffffff" />
          <path d="M12 120 C16 90, 36 82, 60 82 C84 82, 104 90, 108 120 Z" fill="#dc2626" />
          <path d="M42 84 L48 120 L72 120 L78 84 Z" fill="#18181b" />
          <path
            d="M30 58 C30 28, 44 20, 60 20 C76 20, 90 28, 90 58 C90 74, 78 84, 60 84 C42 84, 30 74, 30 58 Z"
            fill="#ef4444"
            stroke="#fbbf24"
            strokeWidth="2.5"
          />
          <path d="M46 22 L54 38 L66 38 L74 22" fill="#f59e0b" />
          <path
            d="M35 44 Q60 39 85 44 L83 60 Q60 65 37 60 Z"
            fill="#18181b"
            stroke="#fbbf24"
            strokeWidth="2"
          />
          <path d="M42 47 L62 45 L56 58 L39 56 Z" fill="#f59e0b" fillOpacity="0.45" />
          <text
            x="60"
            y="77"
            textAnchor="middle"
            fill="#ffffff"
            fontSize="11"
            fontWeight="bold"
            fontFamily="monospace"
          >
            P1
          </text>
        </svg>
      </div>
    );
  }

  if (preset === 'billy') {
    return (
      <div
        className={`${dims} rounded-2xl overflow-hidden bg-zinc-900 border border-amber-500/30 shrink-0 flex items-center justify-center relative ${className}`}
        aria-label="Портрет тренера Билли Аники"
      >
        <svg viewBox="0 0 120 120" className="w-full h-full">
          <defs>
            <linearGradient id="billyBg" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#451a03" />
              <stop offset="100%" stopColor="#18181b" />
            </linearGradient>
          </defs>
          <rect width="120" height="120" fill="url(#billyBg)" />
          <circle cx="60" cy="54" r="44" fill="#f59e0b" fillOpacity="0.14" />
          <path d="M12 120 C14 88, 36 80, 60 80 C84 80, 106 88, 108 120 Z" fill="#d97706" />
          <path d="M36 83 L44 120 L76 120 L84 83 L72 83 L66 104 L54 104 L48 83 Z" fill="#f59e0b" />
          <rect x="48" y="64" width="24" height="22" rx="6" fill="#e09f67" />
          <rect x="38" y="28" width="44" height="44" rx="14" fill="#eba872" />
          <path d="M49 58 Q60 66 71 58" stroke="#fff" strokeWidth="3.5" strokeLinecap="round" fill="none" />
          <path d="M44 43 L54 45" stroke="#451a03" strokeWidth="3" strokeLinecap="round" />
          <path d="M76 43 L66 45" stroke="#451a03" strokeWidth="3" strokeLinecap="round" />
          <circle cx="49" cy="48" r="2.5" fill="#18181b" />
          <circle cx="71" cy="48" r="2.5" fill="#18181b" />
          <path d="M35 40 C34 22, 48 16, 60 18 C74 16, 86 22, 85 40 C81 31, 70 28, 60 29 C50 28, 39 31, 35 40 Z" fill="#5c2d16" />
          <polygon points="60,8 62.5,13 68,13.5 64,17 65,22.5 60,19.5 55,22.5 56,17 52,13.5 57.5,13" fill="#fbbf24" />
        </svg>
      </div>
    );
  }

  if (preset === 'van') {
    return (
      <div
        className={`${dims} rounded-2xl overflow-hidden bg-zinc-900 border border-rose-500/30 shrink-0 flex items-center justify-center relative ${className}`}
        aria-label="Портрет тренера Вана Мастера"
      >
        <svg viewBox="0 0 120 120" className="w-full h-full">
          <defs>
            <linearGradient id="vanBg" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#31101f" />
              <stop offset="100%" stopColor="#09090b" />
            </linearGradient>
          </defs>
          <rect width="120" height="120" fill="url(#vanBg)" />
          <circle cx="60" cy="54" r="42" fill="#e11d48" fillOpacity="0.12" />
          <path d="M12 120 C16 88, 36 80, 60 80 C84 80, 104 88, 108 120 Z" fill="#d4996a" />
          <path d="M32 84 L46 120 L56 120 L42 81 Z" fill="#18181b" />
          <path d="M88 84 L74 120 L64 120 L78 81 Z" fill="#18181b" />
          <rect x="34" y="96" width="52" height="10" fill="#18181b" />
          <circle cx="46" cy="101" r="2.2" fill="#e4e4e7" />
          <circle cx="60" cy="101" r="3" fill="#f43f5e" />
          <circle cx="74" cy="101" r="2.2" fill="#e4e4e7" />
          <rect x="49" y="64" width="22" height="20" rx="5" fill="#c68858" />
          <rect x="39" y="28" width="42" height="43" rx="13" fill="#d4996a" />
          <rect x="42" y="41" width="16" height="10" rx="2" fill="#09090b" stroke="#e4e4e7" strokeWidth="1.2" />
          <rect x="62" y="41" width="16" height="10" rx="2" fill="#09090b" stroke="#e4e4e7" strokeWidth="1.2" />
          <line x1="58" y1="45" x2="62" y2="45" stroke="#e4e4e7" strokeWidth="2" />
          <path d="M51 60 L69 58" stroke="#18181b" strokeWidth="3" strokeLinecap="round" />
          <path d="M36 38 C36 20, 50 15, 60 15 C70 15, 84 20, 84 38 Z" fill="#18181b" />
          <path d="M34 35 Q60 29 86 35" stroke="#e11d48" strokeWidth="3.5" strokeLinecap="round" fill="none" />
        </svg>
      </div>
    );
  }

  if (preset === 'ricardo') {
    return (
      <div
        className={`${dims} rounded-2xl overflow-hidden bg-zinc-900 border border-red-500/30 shrink-0 flex items-center justify-center relative ${className}`}
        aria-label="Портрет тренера Рикардо"
      >
        <svg viewBox="0 0 120 120" className="w-full h-full">
          <defs>
            <linearGradient id="ricardoBg" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#450a0a" />
              <stop offset="100%" stopColor="#18181b" />
            </linearGradient>
          </defs>
          <rect width="120" height="120" fill="url(#ricardoBg)" />
          <circle cx="60" cy="56" r="44" fill="#ef4444" fillOpacity="0.15" />
          <path d="M12 120 C16 88, 36 80, 60 80 C84 80, 104 88, 108 120 Z" fill="#c68652" />
          <rect x="48" y="64" width="24" height="20" rx="6" fill="#b57642" />
          <rect x="38" y="28" width="44" height="44" rx="15" fill="#c68652" />
          <path d="M36 28 Q60 22 84 28 L85 40 Q60 35 35 40 Z" fill="#ef4444" />
          <path d="M83 33 L95 27 L92 39 Z" fill="#dc2626" />
          <circle cx="48" cy="34" r="1.8" fill="#fef2f2" />
          <circle cx="60" cy="32" r="1.8" fill="#fef2f2" />
          <circle cx="72" cy="34" r="1.8" fill="#fef2f2" />
          <path d="M48 57 Q60 67 72 57 Z" fill="#ffffff" />
          <circle cx="49" cy="47" r="2.5" fill="#18181b" />
          <circle cx="71" cy="47" r="2.5" fill="#18181b" />
          <path d="M43 42 Q49 39 54 42" stroke="#18181b" strokeWidth="2.5" fill="none" strokeLinecap="round" />
          <path d="M66 42 Q71 39 77 42" stroke="#18181b" strokeWidth="2.5" fill="none" strokeLinecap="round" />
        </svg>
      </div>
    );
  }

  return (
    <div
      className={`${dims} rounded-2xl overflow-hidden bg-zinc-900 border border-emerald-500/30 shrink-0 flex items-center justify-center relative ${className}`}
      aria-label="Портрет тренера Стива Рэмбо"
    >
      <svg viewBox="0 0 120 120" className="w-full h-full">
        <defs>
          <linearGradient id="steveBg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#064e3b" />
            <stop offset="100%" stopColor="#18181b" />
          </linearGradient>
        </defs>
        <rect width="120" height="120" fill="url(#steveBg)" />
        <circle cx="60" cy="54" r="42" fill="#10b981" fillOpacity="0.12" />
        <path d="M12 120 C16 88, 36 80, 60 80 C84 80, 104 88, 108 120 Z" fill="#065f46" />
        <path d="M36 82 L45 120 L75 120 L84 82 Z" fill="#047857" />
        <rect x="49" y="64" width="22" height="20" rx="5" fill="#d99b66" />
        <rect x="39" y="28" width="42" height="43" rx="13" fill="#e6a972" />
        <path d="M36 32 C38 18, 82 18, 84 32 Z" fill="#78350f" />
        <rect x="36" y="30" width="48" height="9" rx="3" fill="#10b981" />
        <rect x="43" y="42" width="15" height="10" rx="3" fill="#064e3b" stroke="#fbbf24" strokeWidth="1.5" />
        <rect x="62" y="42" width="15" height="10" rx="3" fill="#064e3b" stroke="#fbbf24" strokeWidth="1.5" />
        <line x1="58" y1="45" x2="62" y2="45" stroke="#fbbf24" strokeWidth="1.5" />
        <path d="M50 59 Q60 64 70 59" stroke="#ffffff" strokeWidth="3" strokeLinecap="round" fill="none" />
      </svg>
    </div>
  );
};

interface F1CarTelemetryWidgetProps {
  progressPct: number;
  efficiencyPct?: number;
  completedCount: number;
  totalCount: number;
  isPitStopActive: boolean;
  onTriggerPitStopAlarm?: () => void;
}

/**
 * Formula 1 Car Progress, Efficiency Coefficient & BOX BOX BOX Alarm Widget
 * Uses the user-provided FIA 2026 F1 car image for progress and BOX BOX BOX graphic when the alarm rings.
 */
export const F1CarTelemetryWidget: React.FC<F1CarTelemetryWidgetProps> = ({
  progressPct,
  efficiencyPct,
  completedCount,
  totalCount,
  isPitStopActive,
}) => {
  const clampedPct = Math.max(0, Math.min(100, progressPct));
  const effectiveEffPct =
    typeof efficiencyPct === 'number'
      ? Math.max(0, Math.min(100, efficiencyPct))
      : clampedPct;
  const effCoeffStr = (effectiveEffPct / 100).toFixed(2);

  return (
    <div
      className={`rounded-2xl bg-zinc-950/90 border p-3.5 transition-colors ${
        isPitStopActive
          ? 'border-red-500 shadow-lg shadow-red-500/15'
          : 'border-zinc-800/90'
      }`}
    >
      {/* Top Status Row */}
      <div className="flex items-center justify-between gap-2 mb-2">
        <div className="flex items-center gap-1.5 text-xs font-semibold">
          {isPitStopActive ? (
            <span className="text-red-400 flex items-center gap-1.5 uppercase tracking-wider font-display">
              <Flame className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
              <span>BOX BOX BOX</span>
            </span>
          ) : (
            <span className="text-zinc-300 flex items-center gap-1.5">
              <Flag className="w-3.5 h-3.5 text-amber-400" />
              <span>Болид Ф1 · КЭ: {effCoeffStr} ({effectiveEffPct}%)</span>
            </span>
          )}
        </div>

        <span className="text-xs font-mono-tabular font-bold text-amber-400">
          {clampedPct}% ({completedCount}/{totalCount})
        </span>
      </div>

      {/* Viewport: BOX BOX BOX when alarm plays, or FIA 2026 F1 Car on Progress Track */}
      <div
        className={`relative w-full h-28 sm:h-32 rounded-xl border overflow-hidden ${
          isPitStopActive
            ? 'bg-[#1c1c1c] border-red-500/60'
            : 'bg-[#00113a] border-zinc-800/80'
        }`}
      >
        {isPitStopActive ? (
          /* BOX BOX BOX Display when alarm is ringing */
          <div className="w-full h-full flex items-center justify-center gap-4 px-4 py-2 bg-[#1c1c1c]">
            <img
              src="/assets/aistudio/images_4263797e.jpg"
              alt="BOX BOX BOX"
              className="h-full w-auto object-contain select-none animate-pulse"
            />
            <div className="flex flex-col justify-center leading-none font-display font-extrabold tracking-widest text-lg sm:text-xl select-none">
              <span className="text-red-500">BOX</span>
              <span className="text-white my-0.5">BOX</span>
              <span className="text-amber-400">BOX</span>
            </div>
          </div>
        ) : (
          /* FIA 2026 F1 Car driving forward (leftward) toward the Finish Line in front of its nose */
          <div className="relative w-full h-full flex flex-col justify-between">
            {/* Top Red/White F1 Kerb */}
            <div className="w-full h-1.5 flex opacity-85 shrink-0" aria-hidden="true">
              {Array.from({ length: 16 }).map((_, i) => (
                <div
                  key={i}
                  className={`flex-1 ${
                    i % 2 === 0 ? 'bg-red-600' : 'bg-zinc-100'
                  }`}
                />
              ))}
            </div>

            {/* Main Track Lane: Finish Line in front of the car (left) + Car Path + F1 Car */}
            <div className="relative flex-1 flex items-center px-2.5 overflow-hidden">
              {/* Checkered Finish Line in front of the F1 car (Left Side) */}
              <div className="relative z-20 flex items-center gap-1.5 shrink-0 pr-1">
                <div
                  className="h-20 sm:h-24 w-3.5 grid grid-cols-2 border border-amber-400/60 rounded-sm overflow-hidden shadow-md shadow-black/60"
                  aria-label="Финишная черта перед болидом"
                >
                  {Array.from({ length: 16 }).map((_, idx) => (
                    <div
                      key={idx}
                      className={
                        (Math.floor(idx / 2) + (idx % 2)) % 2 === 0
                          ? 'bg-white'
                          : 'bg-zinc-950'
                      }
                    />
                  ))}
                </div>
                <span className="text-[9px] font-mono-tabular font-bold uppercase tracking-widest text-amber-400 [writing-mode:vertical-rl] rotate-180 select-none">
                  ФИНИШ
                </span>
              </div>

              {/* Track & Path Container */}
              <div className="relative flex-1 h-full flex items-center overflow-hidden">
                {/* Remaining Path in front of the car leading to the Finish Line (Dashed Racing Line) */}
                <div
                  className="absolute left-0 top-1/2 -translate-y-1/2 h-2 flex items-center pointer-events-none z-10"
                  style={{ width: `${Math.max(8, 100 - clampedPct)}%` }}
                >
                  <div className="w-full border-t-2 border-dashed border-amber-400/75" />
                </div>

                {/* Completed Path behind the car from Start (Glowing Amber-Red Trail) */}
                <div
                  className="absolute right-0 top-1/2 -translate-y-1/2 h-2.5 rounded-l-full bg-gradient-to-l from-red-600/80 via-amber-500 to-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.65)] pointer-events-none z-10 transition-all duration-300"
                  style={{ width: `${clampedPct}%` }}
                />

                {/* F1 Car positioned along its path from Start (right, 0%) toward Finish Line in front of it (left, 100%) */}
                <div
                  className="relative z-20 ml-auto transition-all duration-300 ease-out flex items-center"
                  style={{
                    marginRight: `${Math.min(54, Math.round(clampedPct * 0.54))}%`,
                  }}
                >
                  <img
                    src="/assets/aistudio/f1-fia-2026-rules1_95f8db7e.jpg"
                    alt="Болид Формулы-1 на пути к финишу"
                    className="h-16 sm:h-20 w-auto object-contain select-none block rounded-md"
                  />
                </div>
              </div>

              {/* Start Line Marker on the Right (Behind the car) */}
              <div className="relative z-20 pl-1 flex items-center shrink-0">
                <span className="text-[9px] font-mono-tabular font-semibold uppercase tracking-widest text-zinc-400 [writing-mode:vertical-rl] rotate-180 select-none">
                  СТАРТ
                </span>
              </div>
            </div>

            {/* Bottom Dedicated Car Path Progress Bar (Start on Right -> Finish on Left, 95% Max Rank Target) */}
            <div className="w-full px-2.5 pb-1.5 pt-0.5 bg-zinc-950/85 border-t border-zinc-800/80 shrink-0">
              <div className="flex items-center justify-between text-[10px] font-mono-tabular text-zinc-400 mb-1">
                <span className="text-amber-400 font-bold">◀ ФИНИШ (95%+ MAX РАНГ)</span>
                <span>Путь болида: {clampedPct}%</span>
                <span>СТАРТ (0%)</span>
              </div>
              <div className="relative w-full h-2 rounded-full bg-zinc-800 overflow-hidden flex justify-end">
                {/* 95% Top Rank Threshold Marker (5% from left finish line) */}
                <div
                  className="absolute left-[5%] top-0 bottom-0 w-0.5 bg-white z-10"
                  title="95% эффективности — порог высшего ранга месяца"
                />
                <div
                  className="h-full rounded-full bg-gradient-to-l from-amber-500 via-amber-400 to-red-500 transition-all duration-300"
                  style={{ width: `${Math.max(0, clampedPct)}%` }}
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export const GymLockerBanner: React.FC<{
  totalBucks: number;
  rankTitle: string;
  rankBadge: string;
  nextRankTitle?: string;
  nextRankEfficiencyPct?: number;
  efficiencyPct: number;
  monthLabel: string;
  completedCount: number;
  activeCount: number;
  isAlarmPlaying?: boolean;
  onResetMonthlyProgress?: () => void;
}> = ({
  totalBucks,
  rankTitle,
  rankBadge,
  nextRankTitle,
  nextRankEfficiencyPct = 95,
  efficiencyPct,
  monthLabel,
  completedCount,
  activeCount,
  isAlarmPlaying = false,
  onResetMonthlyProgress,
}) => {
  const clampedEffPct = Math.max(0, Math.min(100, efficiencyPct));
  const effCoeff = (clampedEffPct / 100).toFixed(2);
  const totalTasks = completedCount + activeCount;
  const dailyTaskPct =
    totalTasks > 0 ? Math.round((completedCount / totalTasks) * 100) : 0;

  return (
    <div className="relative overflow-hidden rounded-3xl bg-zinc-900 border border-zinc-800 p-5 sm:p-7">
      {/* Subtle Formula 1 Red-Gold Kerb Top Accent Bar */}
      <div className="absolute top-0 left-0 right-0 h-1.5 flex opacity-85" aria-hidden="true">
        {Array.from({ length: 16 }).map((_, idx) => (
          <div
            key={idx}
            className={`flex-1 ${
              idx % 2 === 0 ? 'bg-red-600' : 'bg-amber-400'
            }`}
          />
        ))}
      </div>

      {/* Custom Architectural Vector Gym Backdrop */}
      <svg
        className="absolute inset-0 w-full h-full object-cover opacity-20 pointer-events-none"
        viewBox="0 0 800 320"
        preserveAspectRatio="xMidYMid slice"
        aria-hidden="true"
      >
        <defs>
          <radialGradient id="gymGlow" cx="75%" cy="30%" r="60%">
            <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.45" />
            <stop offset="60%" stopColor="#ef4444" stopOpacity="0.12" />
            <stop offset="100%" stopColor="#0f1115" stopOpacity="0" />
          </radialGradient>
        </defs>
        <rect width="800" height="320" fill="url(#gymGlow)" />
        <g stroke="#3f3f46" strokeWidth="1.5" fill="none" opacity="0.5">
          <rect x="460" y="64" width="70" height="230" rx="4" />
          <rect x="540" y="64" width="70" height="230" rx="4" />
          <rect x="620" y="64" width="70" height="230" rx="4" />
          <rect x="700" y="64" width="70" height="230" rx="4" />
        </g>
      </svg>

      {/* Main Layout: Left Rank & Monthly Efficiency Info + Top-Right F1 Car Progress Widget */}
      <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-7">
          <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-amber-400 mb-2">
            <span>Сезон месяца: {monthLabel}</span>
            <span aria-hidden="true">·</span>
            <span>Сброс прогресса каждый месяц</span>
            <span aria-hidden="true">·</span>
            <span>{rankBadge}</span>
          </div>

          <h1
            className="text-2xl sm:text-4xl font-bold tracking-tight text-white uppercase font-display"
            style={{ textWrap: 'balance' }}
          >
            Ранг месяца: <span className="text-amber-400">{rankTitle}</span>
          </h1>

          <p className="mt-2 text-sm sm:text-base text-zinc-300 leading-relaxed">
            На основе выполненного прогресса рассчитывается{' '}
            <strong className="text-amber-400">
              коэффициент эффективности: {effCoeff} ({clampedEffPct}%)
            </strong>
            . Для получения высшего ранга месяца (Ранг 15) необходима эффективность не менее{' '}
            <strong className="text-white">95% (КЭ ≥ 0.95)</strong>.
          </p>

          {/* Efficiency Coefficient & Monthly Rank Progress Bar */}
          <div className="mt-4 space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-zinc-300">
              <span>
                Коэффициент эффективности:{' '}
                <strong className="text-amber-400 font-mono-tabular">
                  {effCoeff} ({clampedEffPct}%)
                </strong>
                {' · '}
                Капитал месяца:{' '}
                <strong className="text-white font-mono-tabular">${totalBucks} Bucks</strong>
              </span>
              <span className="font-mono-tabular text-zinc-400">
                {clampedEffPct >= 95
                  ? 'Высший ранг месяца достигнут (95%+)'
                  : `До след. ранга (${nextRankTitle || 'выше'}): ${nextRankEfficiencyPct}% · Высший ранг: 95%`}
              </span>
            </div>

            <div className="relative w-full h-2.5 bg-zinc-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-amber-500 rounded-full transition-all duration-300"
                style={{ width: `${clampedEffPct}%` }}
              />
              {/* 95% threshold indicator line */}
              <div
                className="absolute top-0 bottom-0 left-[95%] w-0.5 bg-red-400"
                title="Порог 95% эффективности для получения самого высокого ранга месяца"
              />
            </div>

            {onResetMonthlyProgress && (
              <div className="pt-1 flex items-center justify-between gap-2">
                <span className="text-[11px] text-zinc-400">
                  Выполнено задач в этом месяце: {completedCount} из {totalTasks}
                </span>
                <button
                  type="button"
                  onClick={onResetMonthlyProgress}
                  className="text-xs font-medium text-zinc-400 hover:text-amber-400 underline cursor-pointer"
                >
                  Сбросить прогресс месяца
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Top-Right Corner: F1 Car Progress & BOX BOX BOX Widget */}
        <div className="lg:col-span-5 w-full">
          <F1CarTelemetryWidget
            progressPct={dailyTaskPct}
            efficiencyPct={clampedEffPct}
            completedCount={completedCount}
            totalCount={totalTasks}
            isPitStopActive={isAlarmPlaying}
          />
        </div>
      </div>
    </div>
  );
};
