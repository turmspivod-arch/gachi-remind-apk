import React, { useEffect, useState } from 'react';
import { BellRing, Check, Clock, Mic, Music, Square, Volume2, X } from 'lucide-react';
import {
  CategoryItem,
  CoachProfile,
  DEFAULT_COACHES,
  ReminderItem,
  SOUND_PADS,
} from '../data/gachiData';
import {
  playCoachVoiceover,
  startAlarmRinger,
  stopAlarmRinger,
} from '../utils/gachiAudio';
import { CoachAvatar, F1CarTelemetryWidget } from './GachiArtwork';

interface AndroidAlarmModalProps {
  reminder: ReminderItem | null;
  coachesMap: Record<string, CoachProfile>;
  categories: CategoryItem[];
  completedCount: number;
  totalCount: number;
  defaultCustomTrackId?: string;
  defaultCustomTrackName?: string;
  onComplete: (reminderId: string) => void;
  onSnooze: (reminderId: string) => void;
  onDismiss: () => void;
}

export const AndroidAlarmModal: React.FC<AndroidAlarmModalProps> = ({
  reminder,
  coachesMap,
  categories,
  completedCount,
  totalCount,
  defaultCustomTrackId,
  defaultCustomTrackName,
  onComplete,
  onSnooze,
  onDismiss,
}) => {
  const [isRinging, setIsRinging] = useState(false);
  const [activeSongName, setActiveSongName] = useState<string | undefined>(undefined);

  useEffect(() => {
    if (!reminder) {
      stopAlarmRinger();
      setIsRinging(false);
      return;
    }

    const coach = coachesMap[reminder.coachId] || DEFAULT_COACHES.billy;
    const effectiveCustomTrackId =
      reminder.customTrackId || coach.defaultCustomTrackId || defaultCustomTrackId;
    setIsRinging(true);

    startAlarmRinger({
      soundId: reminder.soundId,
      customTrackId: effectiveCustomTrackId,
      coachVoiceTrackId: coach.voiceTrackId,
      volume: 0.9,
    }).then((res) => {
      if (res.playingCustomSong) {
        setActiveSongName(
          res.songName || reminder.customTrackName || defaultCustomTrackName
        );
      } else {
        setActiveSongName(undefined);
      }
    });

    return () => {
      stopAlarmRinger();
      setIsRinging(false);
    };
  }, [reminder, coachesMap, defaultCustomTrackId, defaultCustomTrackName]);

  if (!reminder) return null;

  const coach = coachesMap[reminder.coachId] || DEFAULT_COACHES.billy;
  const categoryObj = categories.find((c) => c.id === reminder.category);
  const soundObj = SOUND_PADS.find((s) => s.id === reminder.soundId);
  const quote = coach.alarmQuotes[0] || 'Пора выполнить задачу!';

  const ringtoneLabel =
    activeSongName || reminder.customTrackName
      ? `Песня: ${activeSongName || reminder.customTrackName}`
      : soundObj?.title || 'Сигнал будильника';

  const progressPct =
    totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 50;

  const handleToggleAudioLoop = () => {
    if (isRinging) {
      stopAlarmRinger();
      setIsRinging(false);
    } else {
      setIsRinging(true);
      const effectiveCustomTrackId =
        reminder.customTrackId || coach.defaultCustomTrackId || defaultCustomTrackId;
      startAlarmRinger({
        soundId: reminder.soundId,
        customTrackId: effectiveCustomTrackId,
        coachVoiceTrackId: coach.voiceTrackId,
        volume: 0.9,
      });
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="alarm-modal-title"
    >
      <div className="w-full max-w-md max-h-[94vh] overflow-y-auto rounded-3xl bg-zinc-900 border border-zinc-800 p-5 sm:p-6 shadow-2xl relative">
        {/* Top Header */}
        <div className="flex items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-2 text-xs font-medium text-amber-400">
            <BellRing className="w-4 h-4" />
            <span>Сигнал будильника · Пит-стоп</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono-tabular">{reminder.time}</span>
          </div>
          <button
            type="button"
            onClick={() => {
              stopAlarmRinger();
              onDismiss();
            }}
            className="min-h-[44px] min-w-[44px] rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 flex items-center justify-center cursor-pointer"
            aria-label="Закрыть будильник"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Animated F1 Pit-Stop Telemetry Box while Alarm Plays */}
        <div className="mb-4">
          <F1CarTelemetryWidget
            progressPct={progressPct}
            completedCount={completedCount}
            totalCount={totalCount}
            isPitStopActive={isRinging}
          />
        </div>

        {/* Coach Header */}
        <div className="flex items-center gap-4 p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800/90">
          <CoachAvatar coach={coach} size="lg" />
          <div className="min-w-0 flex-1">
            <div className="text-xs text-zinc-400">
              {coach.name} · {coach.title}
            </div>
            <p className="text-sm text-zinc-200 font-medium mt-1 leading-snug">
              «{quote}»
            </p>
            {coach.voiceTrackId && (
              <button
                type="button"
                onClick={() => playCoachVoiceover(coach.voiceTrackId, 1.0)}
                className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-amber-400 hover:underline cursor-pointer"
              >
                <Mic className="w-3.5 h-3.5" />
                <span>Повторить озвучку тренера ({coach.voiceTrackName || 'Аудио'})</span>
              </button>
            )}
          </div>
        </div>

        {/* Task Details */}
        <div className="mt-4">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-zinc-400">
            <span>{categoryObj?.label || 'Задача'}</span>
            <span aria-hidden="true">·</span>
            <span>Награда: ${reminder.rewardBucks} Bucks</span>
            <span aria-hidden="true">·</span>
            <span className="text-amber-400 flex items-center gap-1">
              <Music className="w-3.5 h-3.5" />
              <span>{ringtoneLabel}</span>
            </span>
          </div>

          <h2
            id="alarm-modal-title"
            className="mt-1.5 text-xl sm:text-2xl font-bold text-white font-display uppercase tracking-wide"
          >
            {reminder.title}
          </h2>

          {reminder.note && (
            <p className="mt-1.5 text-sm text-zinc-300 leading-relaxed">
              {reminder.note}
            </p>
          )}
        </div>

        {/* Play / Stop Alarm Sound Button */}
        <div className="mt-4">
          <button
            type="button"
            onClick={handleToggleAudioLoop}
            className={`w-full min-h-[44px] px-4 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors border cursor-pointer ${
              isRinging
                ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border-rose-500/40'
                : 'bg-zinc-800/80 hover:bg-zinc-800 text-zinc-200 border-zinc-700/70'
            }`}
          >
            {isRinging ? (
              <>
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>Остановить звук и пит-стоп</span>
              </>
            ) : (
              <>
                <Volume2 className="w-4 h-4 text-amber-400" />
                <span>Запустить звук и пит-стоп заново</span>
              </>
            )}
          </button>
        </div>

        {/* Primary Android Alarm Actions */}
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => {
              stopAlarmRinger();
              onSnooze(reminder.id);
            }}
            className="min-h-[48px] px-4 py-3 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-100 text-sm font-medium flex items-center justify-center gap-2 transition-colors cursor-pointer whitespace-nowrap"
          >
            <Clock className="w-4 h-4 text-zinc-400" />
            <span>Отложить на 10 мин</span>
          </button>

          <button
            type="button"
            onClick={() => {
              stopAlarmRinger();
              onComplete(reminder.id);
            }}
            className="min-h-[48px] px-4 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-sm font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer whitespace-nowrap"
          >
            <Check className="w-4 h-4 stroke-[2.5]" />
            <span>Выполнено (+${reminder.rewardBucks})</span>
          </button>
        </div>
      </div>
    </div>
  );
};
