import React, { useEffect, useRef, useState } from 'react';
import { Music, Play, Settings2, Sparkles, Square, Trash2, Upload, X } from 'lucide-react';
import {
  CategoryId,
  CategoryItem,
  CoachId,
  CoachProfile,
  getTodayDateStr,
  QUICK_TEMPLATES,
  QuickTemplate,
  ReminderItem,
  REPEAT_LABELS,
  RepeatType,
  SOUND_PADS,
  SoundEffectId,
} from '../data/gachiData';
import {
  playCustomTrackBlob,
  playGachiSound,
  stopAlarmRinger,
} from '../utils/gachiAudio';
import { CustomAudioTrack } from '../utils/customTracksDB';
import { CoachAvatar } from './GachiArtwork';

interface ReminderFormSheetProps {
  isOpen: boolean;
  editingReminder: ReminderItem | null;
  selectedDateStr: string;
  categories: CategoryItem[];
  coachesMap: Record<string, CoachProfile>;
  customTracks: CustomAudioTrack[];
  onUploadCustomTrack: (file: File) => Promise<CustomAudioTrack | null>;
  onDeleteCustomTrack: (id: string) => Promise<void>;
  onOpenCategoryManager: () => void;
  onClose: () => void;
  onSave: (data: Omit<ReminderItem, 'id' | 'completed' | 'snoozedCount'>) => void;
}

export const ReminderFormSheet: React.FC<ReminderFormSheetProps> = ({
  isOpen,
  editingReminder,
  selectedDateStr,
  categories,
  coachesMap,
  customTracks,
  onUploadCustomTrack,
  onDeleteCustomTrack,
  onOpenCategoryManager,
  onClose,
  onSave,
}) => {
  const [title, setTitle] = useState('');
  const [note, setNote] = useState('');
  const [time, setTime] = useState('18:00');
  const [dateStr, setDateStr] = useState(selectedDateStr || getTodayDateStr());
  const [category, setCategory] = useState<CategoryId>('regime');
  const [coachId, setCoachId] = useState<CoachId>('billy');
  const [soundId, setSoundId] = useState<SoundEffectId>('aniki_fanfare');
  const [customTrackId, setCustomTrackId] = useState<string | undefined>(undefined);
  const [customTrackName, setCustomTrackName] = useState<string | undefined>(undefined);
  const [repeat, setRepeat] = useState<RepeatType>('daily');
  const [rewardBucks, setRewardBucks] = useState<100 | 300 | 500>(300);
  const [playingTrackId, setPlayingTrackId] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (editingReminder) {
      setTitle(editingReminder.title);
      setNote(editingReminder.note);
      setTime(editingReminder.time);
      setDateStr(editingReminder.dateStr);
      setCategory(editingReminder.category);
      setCoachId(editingReminder.coachId);
      setSoundId(editingReminder.soundId);
      setCustomTrackId(editingReminder.customTrackId);
      setCustomTrackName(editingReminder.customTrackName);
      setRepeat(editingReminder.repeat);
      setRewardBucks(editingReminder.rewardBucks);
    } else {
      const now = new Date();
      now.setMinutes(now.getMinutes() + 15);
      const defaultTime = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      setTitle('');
      setNote('');
      setTime(defaultTime);
      setDateStr(selectedDateStr || getTodayDateStr());
      setCategory(categories[0]?.id || 'regime');
      setCoachId('billy');
      setSoundId('aniki_fanfare');
      // If user already uploaded a song, preselect their latest song by default so alarms work with user's song immediately
      if (customTracks.length > 0) {
        setCustomTrackId(customTracks[0].id);
        setCustomTrackName(customTracks[0].name);
      } else {
        setCustomTrackId(undefined);
        setCustomTrackName(undefined);
      }
      setRepeat('daily');
      setRewardBucks(300);
    }
    setPlayingTrackId(null);
  }, [editingReminder, isOpen, selectedDateStr, categories, customTracks]);

  useEffect(() => {
    if (!isOpen) {
      stopAlarmRinger();
      setPlayingTrackId(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleApplyTemplate = (tpl: QuickTemplate) => {
    const target = new Date(Date.now() + tpl.defaultTimeOffsetMin * 60000);
    const tStr = `${String(target.getHours()).padStart(2, '0')}:${String(target.getMinutes()).padStart(2, '0')}`;
    setTitle(tpl.title);
    setNote(tpl.note);
    setCategory(tpl.category);
    setCoachId(tpl.coachId);
    setSoundId(tpl.soundId);
    setRewardBucks(tpl.rewardBucks);
    setTime(tStr);
    playGachiSound(tpl.soundId, 0.35);
  };

  const handleSelectCoach = (id: CoachId) => {
    setCoachId(id);
    const selectedCoach = coachesMap[id];
    if (selectedCoach?.defaultCustomTrackId) {
      const found = customTracks.find((t) => t.id === selectedCoach.defaultCustomTrackId);
      if (found) {
        setCustomTrackId(found.id);
        setCustomTrackName(found.name);
        return;
      }
    }
    if (!customTrackId && selectedCoach) {
      setSoundId(selectedCoach.defaultSound);
      playGachiSound(selectedCoach.defaultSound, 0.35);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsUploading(true);
    try {
      const saved = await onUploadCustomTrack(file);
      if (saved) {
        setCustomTrackId(saved.id);
        setCustomTrackName(saved.name);
        setPlayingTrackId(saved.id);
        await playCustomTrackBlob(saved.blob, false, 0.85);
      }
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handlePreviewCustomTrack = async (track: CustomAudioTrack) => {
    if (playingTrackId === track.id) {
      stopAlarmRinger();
      setPlayingTrackId(null);
      return;
    }
    setCustomTrackId(track.id);
    setCustomTrackName(track.name);
    setPlayingTrackId(track.id);
    await playCustomTrackBlob(track.blob, false, 0.85);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    stopAlarmRinger();
    const cleanTitle = title.trim() || 'Будильник дисциплины';
    onSave({
      title: cleanTitle,
      note: note.trim(),
      time,
      dateStr,
      category,
      coachId,
      soundId,
      customTrackId,
      customTrackName,
      repeat,
      rewardBucks,
    });
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/75 backdrop-blur-sm p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="sheet-title"
    >
      <div className="w-full max-w-2xl max-h-[92vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl bg-zinc-900 border border-zinc-800 p-5 sm:p-7 shadow-2xl">
        {/* Mobile grab handle */}
        <div className="w-10 h-1.5 bg-zinc-700 rounded-full mx-auto mb-3 sm:hidden" />

        <div className="flex items-center justify-between gap-4 mb-5">
          <div>
            <h2
              id="sheet-title"
              className="text-xl sm:text-2xl font-bold text-white font-display uppercase tracking-wide"
            >
              {editingReminder ? 'Редактировать будильник' : 'Новый будильник / напоминание'}
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              Настрой время, выбери рубрику, тренера и свою песню для будильника
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              stopAlarmRinger();
              onClose();
            }}
            className="min-h-[44px] min-w-[44px] rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 flex items-center justify-center cursor-pointer shrink-0"
            aria-label="Закрыть форму"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Templates Strip */}
        {!editingReminder && (
          <div className="mb-6">
            <div className="flex items-center gap-1.5 text-xs font-medium text-zinc-400 mb-2.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Быстрые шаблоны по рубрикам:</span>
            </div>
            <div className="flex items-center gap-2 overflow-x-auto pb-1.5">
              {QUICK_TEMPLATES.map((tpl) => (
                <button
                  key={tpl.title}
                  type="button"
                  onClick={() => handleApplyTemplate(tpl)}
                  className="min-h-[40px] px-3.5 py-2 rounded-xl bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 text-xs font-medium text-zinc-200 whitespace-nowrap shrink-0 transition-colors cursor-pointer"
                >
                  {tpl.title}
                </button>
              ))}
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Title & Description */}
          <div className="space-y-3">
            <div>
              <label htmlFor="rem-title" className="block text-xs font-medium text-zinc-300 mb-1.5">
                Название задачи или будильника
              </label>
              <input
                id="rem-title"
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Например: Проверочная по физике / Сделать ДЗ / Тренировка"
                className="w-full min-h-[46px] px-4 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label htmlFor="rem-note" className="block text-xs font-medium text-zinc-300 mb-1.5">
                Заметка или комментарий (необязательно)
              </label>
              <input
                id="rem-note"
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Параграф учебника, тема проверочной или рабочий вес..."
                className="w-full min-h-[44px] px-4 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          {/* Time, Date & Repeat */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label htmlFor="rem-time" className="block text-xs font-medium text-zinc-300 mb-1.5">
                Время будильника
              </label>
              <input
                id="rem-time"
                type="time"
                required
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="w-full min-h-[46px] px-3.5 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white font-mono-tabular focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label htmlFor="rem-date" className="block text-xs font-medium text-zinc-300 mb-1.5">
                Дата
              </label>
              <input
                id="rem-date"
                type="date"
                required
                value={dateStr}
                onChange={(e) => setDateStr(e.target.value)}
                className="w-full min-h-[46px] px-3.5 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white font-mono-tabular focus:outline-none focus:border-amber-500"
              />
            </div>

            <div>
              <label htmlFor="rem-repeat" className="block text-xs font-medium text-zinc-300 mb-1.5">
                Повтор
              </label>
              <select
                id="rem-repeat"
                value={repeat}
                onChange={(e) => setRepeat(e.target.value as RepeatType)}
                className="w-full min-h-[46px] px-3.5 py-2 rounded-xl bg-zinc-950 border border-zinc-800 text-sm text-white focus:outline-none focus:border-amber-500"
              >
                {(Object.keys(REPEAT_LABELS) as RepeatType[]).map((repKey) => (
                  <option key={repKey} value={repKey}>
                    {REPEAT_LABELS[repKey]}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Categories & Reward Selection */}
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-xs font-medium text-zinc-300">
                  Рубрика
                </span>
                <button
                  type="button"
                  onClick={onOpenCategoryManager}
                  className="text-xs font-medium text-amber-400 hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <Settings2 className="w-3.5 h-3.5" />
                  <span>Редактировать рубрики</span>
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setCategory(cat.id)}
                    className={`min-h-[42px] px-3.5 py-2 rounded-xl text-xs font-medium transition-colors border cursor-pointer whitespace-nowrap ${
                      category === cat.id
                        ? 'bg-amber-500 text-zinc-950 border-amber-500 font-semibold'
                        : 'bg-zinc-950 text-zinc-300 border-zinc-800 hover:bg-zinc-800'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <span className="block text-xs font-medium text-zinc-300 mb-2">
                Награда за выполнение
              </span>
              <div className="grid grid-cols-3 gap-2">
                {([100, 300, 500] as const).map((bucks) => (
                  <button
                    key={bucks}
                    type="button"
                    onClick={() => setRewardBucks(bucks)}
                    className={`min-h-[44px] px-3 py-2 rounded-xl text-xs font-mono-tabular font-semibold transition-colors border cursor-pointer whitespace-nowrap ${
                      rewardBucks === bucks
                        ? 'bg-amber-500 text-zinc-950 border-amber-500'
                        : 'bg-zinc-950 text-zinc-300 border-zinc-800 hover:bg-zinc-800'
                    }`}
                  >
                    ${bucks} Bucks
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Coach Selector (Including Custom Coaches) */}
          <div>
            <span className="block text-xs font-medium text-zinc-300 mb-2">
              Ответственный тренер
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {Object.values(coachesMap).map((c) => {
                const isSelected = coachId === c.id;
                return (
                  <button
                    key={c.id}
                    type="button"
                    onClick={() => handleSelectCoach(c.id)}
                    className={`p-3 rounded-2xl border text-left flex items-center gap-3 transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-zinc-800 border-amber-500'
                        : 'bg-zinc-950 border-zinc-800 hover:bg-zinc-800/60'
                    }`}
                  >
                    <CoachAvatar coach={c} size="sm" />
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-white truncate">
                        {c.name}
                      </div>
                      <div className="text-[11px] text-zinc-400 truncate">
                        {c.title} · {c.specialty.split(',')[0]}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* User Song Selector for Alarm */}
          <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                  <Music className="w-4 h-4 text-amber-400" />
                  <span>Песня пользователя на будильник</span>
                </div>
                <p className="text-[11px] text-zinc-400 mt-0.5">
                  Выбери свою песню из списка или загрузи новый аудиофайл с устройства
                </p>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="audio/*"
                onChange={handleFileChange}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
                className="min-h-[42px] px-3.5 py-2 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-300 text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer whitespace-nowrap shrink-0"
              >
                <Upload className="w-4 h-4" />
                <span>{isUploading ? 'Загрузка...' : 'Выбрать песню с устройства'}</span>
              </button>
            </div>

            {customTracks.length > 0 && (
              <div className="space-y-1.5 pt-2 border-t border-zinc-800/80 max-h-48 overflow-y-auto">
                <div className="text-[11px] text-zinc-400">
                  Доступные песни с устройства ({customTracks.length}):
                </div>
                <div className="grid grid-cols-1 gap-2">
                  {customTracks.map((track) => {
                    const isSelected = customTrackId === track.id;
                    const isPlayingThis = playingTrackId === track.id;
                    return (
                      <div
                        key={track.id}
                        className={`flex items-center justify-between gap-2 px-3 py-2 rounded-xl border ${
                          isSelected
                            ? 'bg-zinc-800 border-amber-500'
                            : 'bg-zinc-900 border-zinc-800'
                        }`}
                      >
                        <button
                          type="button"
                          onClick={() => {
                            setCustomTrackId(track.id);
                            setCustomTrackName(track.name);
                          }}
                          className="text-left flex-1 min-w-0 cursor-pointer"
                        >
                          <div className="text-xs font-semibold text-white truncate">
                            {track.name}
                          </div>
                          <div className="text-[11px] text-amber-400">
                            {isSelected
                              ? 'Активна как песня будильника'
                              : 'Нажми, чтобы поставить на будильник'}
                          </div>
                        </button>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => handlePreviewCustomTrack(track)}
                            className="min-h-[36px] min-w-[36px] rounded-lg bg-zinc-950 hover:bg-zinc-700 text-amber-400 flex items-center justify-center cursor-pointer"
                            aria-label={isPlayingThis ? 'Остановить' : 'Прослушать трек'}
                          >
                            {isPlayingThis ? (
                              <Square className="w-3.5 h-3.5 fill-current" />
                            ) : (
                              <Play className="w-3.5 h-3.5 fill-current" />
                            )}
                          </button>
                          <button
                            type="button"
                            onClick={async () => {
                              if (playingTrackId === track.id) {
                                stopAlarmRinger();
                                setPlayingTrackId(null);
                              }
                              if (customTrackId === track.id) {
                                setCustomTrackId(undefined);
                                setCustomTrackName(undefined);
                              }
                              await onDeleteCustomTrack(track.id);
                            }}
                            className="min-h-[36px] min-w-[36px] rounded-lg bg-zinc-950 hover:bg-rose-950/60 text-zinc-400 hover:text-rose-400 flex items-center justify-center cursor-pointer"
                            aria-label="Удалить трек"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Built-in Gachi & F1 Sound Effect Selector */}
          <div>
            <span className="block text-xs font-medium text-zinc-300 mb-2">
              Стандартные звуки качалки и Формулы-1 {customTrackId ? '(нажми, если хочешь заменить песню на сигнал)' : ''}
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {SOUND_PADS.map((pad) => {
                const isSelected = !customTrackId && soundId === pad.id;
                return (
                  <div
                    key={pad.id}
                    className={`flex items-center justify-between gap-2 px-3.5 py-2.5 rounded-xl border ${
                      isSelected
                        ? 'bg-zinc-800 border-amber-500'
                        : 'bg-zinc-950 border-zinc-800'
                    }`}
                  >
                    <button
                      type="button"
                      onClick={() => {
                        setCustomTrackId(undefined);
                        setCustomTrackName(undefined);
                        setSoundId(pad.id);
                      }}
                      className="text-left flex-1 min-w-0 cursor-pointer"
                    >
                      <div className="text-xs font-semibold text-white truncate">
                        {pad.title}
                      </div>
                      <div className="text-[11px] text-zinc-400 truncate">
                        {pad.bpmLabel}
                      </div>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        stopAlarmRinger();
                        setPlayingTrackId(null);
                        setCustomTrackId(undefined);
                        setCustomTrackName(undefined);
                        setSoundId(pad.id);
                        playGachiSound(pad.id, 0.45);
                      }}
                      className="min-h-[36px] min-w-[36px] rounded-lg bg-zinc-900 hover:bg-zinc-700 text-amber-400 flex items-center justify-center shrink-0 cursor-pointer"
                      aria-label={`Прослушать ${pad.title}`}
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Submit & Cancel Actions */}
          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={() => {
                stopAlarmRinger();
                onClose();
              }}
              className="min-h-[46px] px-5 py-2.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-sm font-medium transition-colors cursor-pointer whitespace-nowrap"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="min-h-[46px] px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-sm font-bold transition-colors cursor-pointer whitespace-nowrap"
            >
              Сохранить будильник
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
