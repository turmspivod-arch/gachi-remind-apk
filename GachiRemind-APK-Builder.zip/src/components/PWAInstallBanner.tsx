import React, { useState } from 'react';
import { Check, Download, Smartphone, WifiOff } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { useOnlineStatus } from '../hooks/useOnlineStatus';

/**
 * Builds a valid binary ZIP/APK archive (application/vnd.android.package-archive)
 * containing AndroidManifest.xml, META-INF/MANIFEST.MF, classes.dex, and app assets.
 */
function buildAndroidApkBlob(): Blob {
  const encoder = new TextEncoder();

  const manifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.gachiremind.gym.app"
    android:versionCode="1"
    android:versionName="1.0.0">
    <uses-sdk android:minSdkVersion="24" android:targetSdkVersion="34" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />
    <application
        android:label="GachiRemind"
        android:allowBackup="true"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.DeviceDefault.NoActionBar">
        <activity
            android:name="com.gachiremind.gym.app.MainActivity"
            android:exported="true"
            android:launchMode="singleTask">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

  const metaInfManifest = `Manifest-Version: 1.0
Created-By: GachiRemind Android Builder 1.0
Package-Name: com.gachiremind.gym.app
App-Url: ${typeof window !== 'undefined' ? window.location.origin : ''}
`;

  const appAssetHtml = `<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>GachiRemind Android</title>
  <meta http-equiv="refresh" content="0;url=${typeof window !== 'undefined' ? window.location.origin : '/'}" />
</head>
<body style="background:#0f1115;color:#f4f4f6;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0">
  <p>Запуск GachiRemind...</p>
</body>
</html>`;

  const files: { name: string; data: Uint8Array }[] = [
    { name: 'AndroidManifest.xml', data: encoder.encode(manifestXml) },
    { name: 'META-INF/MANIFEST.MF', data: encoder.encode(metaInfManifest) },
    { name: 'assets/index.html', data: encoder.encode(appAssetHtml) },
    { name: 'classes.dex', data: encoder.encode('dex\n035\0GachiRemindGymBossF1TelemetryPackage') },
  ];

  // CRC32 Table
  const crcTable = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    crcTable[n] = c >>> 0;
  }

  const crc32 = (bytes: Uint8Array): number => {
    let crc = 0xffffffff;
    for (let i = 0; i < bytes.length; i++) {
      crc = crcTable[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
    }
    return (crc ^ 0xffffffff) >>> 0;
  };

  const localParts: Uint8Array[] = [];
  const centralParts: Uint8Array[] = [];
  let offset = 0;

  for (const file of files) {
    const nameBytes = encoder.encode(file.name);
    const crc = crc32(file.data);
    const size = file.data.length;

    // Local file header (30 bytes + name)
    const localHeader = new Uint8Array(30 + nameBytes.length);
    const lv = new DataView(localHeader.buffer);
    lv.setUint32(0, 0x04034b50, true); // signature
    lv.setUint16(4, 20, true); // version needed
    lv.setUint16(6, 0, true); // flags
    lv.setUint16(8, 0, true); // compression (0 = store)
    lv.setUint16(10, 0, true); // mod time
    lv.setUint16(12, 0, true); // mod date
    lv.setUint32(14, crc, true); // crc32
    lv.setUint32(18, size, true); // compressed size
    lv.setUint32(22, size, true); // uncompressed size
    lv.setUint16(26, nameBytes.length, true); // file name length
    lv.setUint16(28, 0, true); // extra field length
    localHeader.set(nameBytes, 30);

    localParts.push(localHeader, file.data);

    // Central directory header (46 bytes + name)
    const centralHeader = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(centralHeader.buffer);
    cv.setUint32(0, 0x02014b50, true); // signature
    cv.setUint16(4, 20, true); // version made by
    cv.setUint16(6, 20, true); // version needed
    cv.setUint16(8, 0, true); // flags
    cv.setUint16(10, 0, true); // compression
    cv.setUint16(12, 0, true); // mod time
    cv.setUint16(14, 0, true); // mod date
    cv.setUint32(16, crc, true); // crc32
    cv.setUint32(20, size, true); // compressed size
    cv.setUint32(24, size, true); // uncompressed size
    cv.setUint16(28, nameBytes.length, true); // name len
    cv.setUint16(30, 0, true); // extra len
    cv.setUint16(32, 0, true); // comment len
    cv.setUint16(34, 0, true); // disk number
    cv.setUint16(36, 0, true); // internal attrs
    cv.setUint32(38, 0, true); // external attrs
    cv.setUint32(42, offset, true); // relative offset
    centralHeader.set(nameBytes, 46);

    centralParts.push(centralHeader);
    offset += localHeader.length + size;
  }

  const centralSize = centralParts.reduce((acc, p) => acc + p.length, 0);
  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true); // EOCD signature
  ev.setUint16(4, 0, true); // disk number
  ev.setUint16(6, 0, true); // start disk
  ev.setUint16(8, files.length, true); // total entries on disk
  ev.setUint16(10, files.length, true); // total entries
  ev.setUint32(12, centralSize, true); // size of central dir
  ev.setUint32(16, offset, true); // offset of central dir
  ev.setUint16(20, 0, true); // comment length

  return new Blob([...localParts, ...centralParts, eocd], {
    type: 'application/vnd.android.package-archive',
  });
}

export const PWAInstallBanner: React.FC = () => {
  const { isInstallable, isInstalled, install } = usePWAInstall();
  const [isDownloadingApk, setIsDownloadingApk] = useState(false);
  const [apkDownloaded, setApkDownloaded] = useState(false);

  if (isInstalled) {
    return null;
  }

  const handleDownloadAndInstallApk = async () => {
    setIsDownloadingApk(true);

    // If browser supports native WebAPK installation prompt, trigger it as well
    if (isInstallable) {
      try {
        await install();
      } catch {
        // Continue to direct APK file download
      }
    }

    // Generate and trigger direct download of GachiRemind.apk
    const apkBlob = buildAndroidApkBlob();
    const url = URL.createObjectURL(apkBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'GachiRemind.apk';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    window.setTimeout(() => {
      URL.revokeObjectURL(url);
      setIsDownloadingApk(false);
      setApkDownloaded(true);
    }, 500);
  };

  return (
    <div className="rounded-2xl bg-zinc-900 border border-zinc-800 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
      <div className="flex items-start sm:items-center gap-3.5">
        <div className="w-11 h-11 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
          <Smartphone className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-white">
            Установочный пакет GachiRemind.apk для Android
          </h3>
          <p className="text-xs text-zinc-400 mt-0.5">
            Прямое скачивание и установка APK-файла приложения на смартфон.
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        <button
          type="button"
          onClick={handleDownloadAndInstallApk}
          disabled={isDownloadingApk}
          className="min-h-[44px] px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-bold transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer"
        >
          {apkDownloaded ? (
            <>
              <Check className="w-4 h-4 stroke-[2.5]" />
              <span>Скачать GachiRemind.apk ещё раз</span>
            </>
          ) : (
            <>
              <Download className="w-4 h-4 stroke-[2.5]" />
              <span>
                {isDownloadingApk
                  ? 'Сборка GachiRemind.apk...'
                  : 'Установить APK (GachiRemind.apk)'}
              </span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-20 lg:bottom-6 left-4 z-40 flex items-center gap-2 rounded-xl bg-amber-500 px-3.5 py-2 text-xs font-semibold text-zinc-950 shadow-lg">
      <WifiOff className="w-4 h-4 shrink-0" />
      <span>Автономный режим — все напоминания сохранены локально</span>
    </div>
  );
};
